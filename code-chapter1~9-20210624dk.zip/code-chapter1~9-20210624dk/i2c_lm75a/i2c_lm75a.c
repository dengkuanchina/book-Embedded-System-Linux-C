#include "../includeAll.h"
//lm75a读取数据
int main(void)
{
    unsigned char temp[2];
    I2C_Init();
    while (1)
    {
        LM75A_ReadTemTwoByte(temp);
        printf("%d.%d\n",temp[0],(temp[1]>0x7F)*5);
        sleep(1);
    }



    return 0;
}
