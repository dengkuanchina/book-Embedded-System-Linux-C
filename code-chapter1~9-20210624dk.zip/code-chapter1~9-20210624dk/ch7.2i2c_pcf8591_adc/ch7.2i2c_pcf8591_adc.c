#include "../includeAll.h"

#define Vref 3300

int main(void)
{
    unsigned char nResult, tempValue;

    I2C_Init();

    while (1)
    {
        nResult = PCF8591_ADC_Input(0x00, &tempValue);
        if (nResult == 0)
        {
            printf("read adc ok: value=%x, voltage= %d mV\n", tempValue, tempValue * Vref / 255);
        }
        else
        {
            printf("read adc error!\n");
        }

        sleep(1);
    }
}
