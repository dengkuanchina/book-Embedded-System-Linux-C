#include "../includeAll.h"

int main(void)
{
    ADXL345XYZDATA adxl345xyzData;

    adxl345_init(3);
    
    while (1)
    {
        adxl345_readXYZdata(&adxl345xyzData);

        printf(" XYZ data：\n");
        printf("x=%f,y=%f,z=%f,\n", adxl345xyzData.fXdata, adxl345xyzData.fYdata, adxl345xyzData.fZdata);

        printf(" angle of tilt data：\n");
        printf("x=%f,y=%f,z=%f,\n", adxl345xyzData.Angel_x, adxl345xyzData.Angel_y, adxl345xyzData.Angel_z);

        sleep(1);
    }

    return 0;
}
