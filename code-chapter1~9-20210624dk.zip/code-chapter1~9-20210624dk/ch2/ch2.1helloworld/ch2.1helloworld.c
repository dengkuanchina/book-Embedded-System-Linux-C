#include <stdio.h>
 int main()
 {
     printf("Hello world, linux c!\n");
     return 0;
 }
