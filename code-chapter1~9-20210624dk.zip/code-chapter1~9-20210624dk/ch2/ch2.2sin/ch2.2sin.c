
#include <stdio.h>
#include <math.h>
int main()
{
  printf("%f\n", sin(0));
  return 0;
}
