#include "stdio.h"

void hello()
{
    printf("hello, linux c, test2_3 \n");
}
