//test2_3.c

#include "stdio.h"
#include "b.h"

int main()
{
    hello();
    return 0;
}
