#include "stdio.h"

int hello()
{
    return 0;
}

