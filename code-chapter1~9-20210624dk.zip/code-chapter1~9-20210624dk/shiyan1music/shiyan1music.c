#include "../includeAll.h"

#define PortBEEP PG
#define PinBEEP 3
#define PortKEY0 PG
#define PinKEY0 4
#define PortKEY1 PG
#define PinKEY1 5

//音阶频率表
int MusicalNote[] = {247, 262, 294, 330, 349, 392, 440, 494, 523, 587, 659, 698, 784, 880, 988, 1046, 1000};
/////////////////////C    C#    D    D#   E    F    F#   G    G#   A    A#   B
/////////////////////DO   C#    Re   D#   Mi   Fa   F#   So   G#   La   A#   Si
/////////////////////低7  1     2    3    4    5    6    7    中1  中2  中3  中4  中5  中6  中7   高1   高2    不发音
int MusicalNote_1[] = {262, 277, 294, 311, 330, 349, 370, 392, 415, 440, 466, 494,
                       523, 554, 587, 622, 659, 698, 740, 784, 831, 880, 932, 988,
                       1046, 1109, 1175, 1245, 1318, 1397, 1480, 1568, 1661, 1760, 1865, 1976};
//音阶测试
int test_music[] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11,
                    12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23,
                    24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35};
int test_time[] = {10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10,
                   10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10,
                   10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10};
//歌曲分解
//生日歌
int birthday_frq[] = {212, 212, 190, 212, 159, 169,
                      212, 212, 190, 212, 142, 159,
                      212, 212, 106, 126, 159, 169, 190,
                      119, 119, 126, 159, 142, 159, 0};
int birthday_time[] = {9, 3, 12, 12, 12, 24,
                       9, 3, 12, 12, 12, 24,
                       9, 3, 12, 12, 12, 12, 12,
                       9, 3, 12, 12, 12, 24, 0};
//想去远方的山川
//音阶序列
int xq_frq[] = {
    5, 10, 10, 5, 5, 9, 9, 16, 8, 8, 8, 9, 10, 5, 5, 16,  //想去远方的山川，想去海边看海鸥
    6, 8, 8, 6, 5, 10, 10, 16, 9, 8, 8, 6, 9, 16,         //不管风雨有多少，有你就足够
    5, 10, 10, 5, 5, 9, 9, 16, 8, 8, 8, 6, 5, 10, 10, 16, //喜欢看你的嘴角，喜欢看你的眉梢
    6, 11, 11, 6, 5, 10, 10, 16, 9, 8, 8, 6, 8, 16,       //白云挂在那蓝天，像你的微笑
    5, 12, 5, 5, 12, 5, 9, 16, 8, 6, 8, 8, 8, 10, 12, 16, //你笑起来真好看，像春天的花一样！
    8, 6, 8, 8, 8, 13, 12, 10, 9, 8, 6, 8, 8, 10, 9, 16,  //把所有的烦恼，所有的忧愁，统统都吹散
    5, 12, 5, 5, 12, 5, 9, 16, 8, 6, 8, 8, 13, 12, 16,    //你笑起来真好看，像夏天的阳光
    8, 8, 8, 13, 12, 10, 9, 8, 6, 8, 8, 9, 8, 16,         //整个世界全部的时光，美得像画卷。
};

//音长序列
int xq_time[] = {
    4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, //想去远方的山川，想去海边看海鸥
    4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 8, 4,       //不管风雨有多少，有你就足够
    4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, //喜欢看你的嘴角，喜欢看你的眉梢
    4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 8, 4,       //白云挂在那蓝天，像你的微笑
    4, 4, 2, 2, 4, 4, 4, 4, 4, 4, 2, 2, 4, 4, 8, 4, //你笑起来真好看，像春天的花一样！
    4, 4, 2, 2, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 8, 4, //把所有的烦恼，所有的忧愁，统统都吹散
    4, 4, 2, 2, 4, 4, 4, 4, 4, 4, 4, 4, 4, 8, 4,    //你笑起来真好看，像夏天的阳光
    4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 8, 4,       //整个世界全部的时光，美得像画卷。
};
//播放一组音阶
void Sound(int frq, int runtime)
{
    int i;
    int frq_time;
    int loop;                                          //循环次数
    frq_time = 500000 / MusicalNote[frq];              //半个周期（延时时间） 1秒是1000000us，一半即500000
    loop = xq_time[runtime] * 100000 / (frq_time * 2); //时间除以周期，得到音节循环次数
    for (i = 0; i < loop; i++)
    {
        if (MusicalNote[frq] != 1000)
        {

            GPIO_SetPin(PortBEEP, PinBEEP, 0);
            usleep(frq_time);
            GPIO_SetPin(PortBEEP, PinBEEP, 1);
            usleep(frq_time);
        }
        else
            usleep(1000);
    }
}
//播放歌曲
void sing()
{
    int i = 0;
    for (i = 0; i < sizeof(xq_time) / sizeof(xq_time[0]); i++)
    {
		Sound(xq_frq[i], xq_time[i]);
        if ( GPIO_GetPin(PortKEY0, PinKEY0) == 0)
		{
			while (GPIO_GetPin(PortKEY0, PinKEY0) == 0)     ; //保证每次按键只作用1次
			break; //按键按下，即key0==0时，立即停止播放
		}
    }
}

int main(int argc, char *argv[])
{
    int key0 = 0;
    int key1 = 0;
    int cycle = 100;
    int duty = 60;

    GPIO_Init();
    GPIO_ConfigPinMode(PortBEEP, PinBEEP, OUT);
    GPIO_ConfigPinMode(PortKEY0, PinKEY0, IN);
    GPIO_ConfigPinMode(PortKEY1, PinKEY1, IN);
    GPIO_SetPin(PortBEEP, PinBEEP, 0);

    PWM1_Init();
    PWM1_Config(cycle, duty);
    printf("cycle=%d;--duty=%d\n", cycle, duty);

    while (1)
    {
        key0 = GPIO_GetPin(PortKEY0, PinKEY0);
        key1 = GPIO_GetPin(PortKEY1, PinKEY1);

        if (key0 == 0) //按下key0，蜂鸣器播放音乐
        {
			usleep(1000);
			key0 = GPIO_GetPin(PortKEY0, PinKEY0);
			if (key0 == 0)
			{
				sing();
			}            
        }

        if (key1 == 0) //按下key1，生成PWM波，占空比逐次增加20%
        {
            duty += 20;
            if (duty > 100)
            {
                duty = 0; //开发板中发光二极管是共阳极，占空比为0%时最亮；占空比为100%时，熄灭不亮
            }

            printf("cycle=%d;--duty=%d\n", cycle, duty);
            PWM1_Config(cycle, duty);

            while (GPIO_GetPin(PortKEY1, PinKEY1) == 0)
                ; //保证每次按键只作用1次
        }
		usleep(1000);
    }
    GPIO_Free();
    PWM1_UnInit();
    return 0;
}
