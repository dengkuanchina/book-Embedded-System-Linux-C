#include "../includeAll.h"

//功能： 测试SPI波形
//spi模式3 CPOL=1;CPHA=1

int main(void)
{
    SPI_Init(3);
    
    GPIO_SetPin(PortCS, PinCS, 0);
    usleep(10);
    SPI_mode3_RWByte(0x01);
    usleep(10);
    SPI_mode3_RWByte(0x02);
    usleep(10);
    GPIO_SetPin(PortCS, PinCS, 1);
    
    return 0;
}
