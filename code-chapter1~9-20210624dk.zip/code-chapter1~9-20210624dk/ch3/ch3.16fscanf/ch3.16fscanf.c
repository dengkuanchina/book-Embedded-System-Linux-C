#include <stdio.h>
//   用法： ./test3_16fscanf
//     运行结果：
// 输入1: -1000 10 abcdefg 1.23
// 回显1: -1000 16 abcde 1.230000    //可见，字符串最多有5个字符
// 输入2: -1000 10 a2b 1.23
// 回显2: -1000 16 a 1.230000      //可见，字符串碰到数字就会停止，而不是跳过
int main()
{
    int i;
    unsigned int j;
    char s[5];
    float f;
    fscanf(stdin,"%d %x %5[a-z] %*s %f", &i,&j,s,&f); //%x是16进制
    printf("%d %d %s %f \n", i,j,s,f);
}