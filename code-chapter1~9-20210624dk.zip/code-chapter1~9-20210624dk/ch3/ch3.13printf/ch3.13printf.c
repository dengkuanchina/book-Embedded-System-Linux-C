#include <stdio.h>
//   用法： ./test3_13printf
//     运行结果：
// -100 3.141590 96
// 150 150
//     备注：无。
int main()
{
    int i = 150;
    int j = -100;
    double k = 3.14159;
    printf("%d %f %x\n", j, k, i);
    printf("%2d %*d\n”", i, 2, i); //参数2会代入格式*中，而与%2d同意义
}