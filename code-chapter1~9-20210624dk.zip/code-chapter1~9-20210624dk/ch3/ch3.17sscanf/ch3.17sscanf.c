#include <stdio.h>
#include <string.h>
//   用法： ./test3_17sscanf
//     运行结果：
// 当if(1)时，结果是：i=10 j=16 s1=aaaaaaaa f=1.230000
// 当if(0)时，结果是：i=10 j=16 s1=aaaaa f=1.100000
// 可见，当if(0)时，由于%5[a-z]只取5个a，导致后面的2个aa引起了%f的错误识别，从而没有识别出来变量f，所以变量f保持原值。
//     备注：网上搜了一些资料，感觉sscanf非常灵活，不容易掌握。
int main(int argc, char *argv[])
{
    int i = 1;
    unsigned int j = 2;
    char input[] = "10 0x10 aaaaaaaa  bbbbbbbb 1.23 ";
    char s1[5], s2[5];
    float f = 1.1;
    if (strcmp(argv[1], "1") == 0)
    {
        sscanf(input, "%d %x %[a-z] %*s %f", &i, &j, s1, &f); //*代表该对应的参数数据忽略。
    }
    else
    {
        sscanf(input, "%d %x %5[a-z] %*s %f", &i, &j, s1, &f); //*代表该对应的参数数据忽略。
    }

    printf("i=%d j=%d s1=%s f=%f\n", i, j, s1, f);
}
