#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
// 用法： ./test3_1creat file1 file2 file3  （也就是说，可以一次创建多个文件）
//   运行结果：
// create file file1 success!
// create file file2 success!
// create file file3 success!
void create_file(char *filename)
{
    //创建的文件具有什么样的属性？
    if (creat(filename, 0700) < 0)
    {
        printf("create file: %s failure!\n", filename);
        exit(EXIT_FAILURE);
    }
    else
    {
        printf("create file %s success!\n", filename);
    }
}

int main(int argc, char *argv[])
{
    int i;
    if (argc < 2)
    {
        printf("you haven't input the filename,please try again!\n");
        exit(EXIT_FAILURE);
    }
    for (i = 1; i < argc; i++) //可以一次输入多个文件名，创建多个文件。
    {
        create_file(argv[i]);
    }
    exit(EXIT_SUCCESS);
}
