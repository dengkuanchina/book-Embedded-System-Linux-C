#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
//   用法：  ./test3_5fwrite
//   运行结果： 无执行过程无现象。运行ls -al，可以看到新增加了文件tmp，大小72字节。
//   注意：1.因为使用的是w+选项，tmp文件如果不存在就会自动创建。
//   2.生成的tmp文件，用vim打开，在"命令"模式中输入:%!xxd命令，即可用16进制查看文件。可以看到，tmp文件中没有填充的内容都是0x00。
#define set_buffer(x, y)            \
    {                               \
        strcpy(buffer[x].name, y);  \
        buffer[x].size = strlen(y); \
    }
#define nmemb 3
struct test
{
    char name[20];
    int size;
} buffer[nmemb];
int main()
{
    FILE *stream;
    set_buffer(0, "Linux!");
    set_buffer(1, "FreeBSD!");
    set_buffer(2, "Windows2000.");
    stream = fopen("tmp", "w+"); //w+：打开可读写文件，若文件存在则文件长度清0，即该文件内容会消失；若文件不存在则建立该文件
        //注意，路径不能使用~
    if (NULL == stream)
    {
        printf("errno = %d\n", errno); //错误代码2的含义：No such file or directory
        exit(1);
    }
    else
    {
        fwrite(buffer, sizeof(struct test), nmemb, stream);
        fclose(stream);
    }
}
