#include <stdio.h>
#include <stdlib.h> 
#include <unistd.h>     //for read close
#include <fcntl.h>      //for open 
//  用法1，输出到标准输出：  ./test3_4buffer 
//  运行结果： 
//  before fork
//  Parent did not changed: globa = 4 vari = 4
//  Child changed: globa = 5 vari = 3
//  用法2，重定向到文件：  ./test3_4buffer > temp
//  运行结果：  程序运行无提示。然后使用cat temp，可以看到temp文件的内容为：
//  before fork
//  Parent did not changed: globa = 4 vari = 4
//  before fork       （两种执行方式的差异，就在于多了这一句！）
//  Child changed: globa = 5 vari = 3
int globa = 4;
int main (void )
{
    pid_t pid;
    int vari = 4;
    printf ("before fork\n" );//换行符号\n不能少，去掉的话，这句话就会父子进程都出现，证明了printf的数据是行缓冲，没有及时flush并显示。
    pid = fork() ;
    if ( pid < 0 ){
        printf ("fork error\n");
        exit (0);
    }
    else if (pid == 0){
        globa++ ;
        vari--;
        printf("Child changed: ");
    }
    else
        printf("Parent did not changed: ");
    printf("globa = %d vari = %d\n",globa,vari);
    exit(0);
}
