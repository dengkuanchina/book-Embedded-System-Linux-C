#include <stdio.h>
// 用法： ./test3_14fprintf
//     运行结果：
// -100  3.141590  96
// 150 150
//     备注：无。
int main()
{
    int i = 150;
    int j = -100;
    double k = 3.14159;
    fprintf(stdout, "%d  %f  %x \n", j, k, i);
    fprintf(stdout, "%2d %*d\n", i, 2, i);
}