#include <stdio.h>
//   用法： ./test3_12gets
//     运行结果： 输入数据123456，然后会回显123456。可见，gets()函数很容易造成数组溢出，非常危险。
//     备注：1.编译时，会出现2个报警，这是因为程序中使用的gets是非常不安全的：
//     warning: implicit declaration of function ‘gets’ 和warning: the `gets' function is dangerous and should not be used.
//     这是因为gets()函数比较危险，所以被从C11标准中删除了。gets()以前是在<stdio.h>中，现在被删除了。
//     这个问题的解决方法是使用fgets，但由于fgets函数是为读取文件设计的，所以读取键盘是没有gets那么方便。
//     用法如下：fgets(name, sizeof(name), stdin);	//stdin意思是键盘输入
int main(void)
{
    char str1[5];
    gets(str1);
    printf("%s\n", str1);
}