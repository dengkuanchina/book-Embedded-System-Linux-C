#include "../includeAll.h"

#define PortLED1 PG
#define PinLED1 3

//用法: time ./pwm_gpio 100 100
//---------------------------------------
int main(int argc, char *argv[])
{
    int i, dutyHigh, dutyLow;
    dutyHigh = atoi(argv[1]);
    dutyLow = atoi(argv[2]);
    printf("argv[1] is dutyHigh=%d;--argv[2] is dutyLow =%d\n", dutyHigh, dutyLow);

    //-------------------------------
    GPIO_Init();
    GPIO_ConfigPinMode(PortLED1, PinLED1, OUT);
    GPIO_SetPin(PortLED1, PinLED1, 1); //设置PG3为输出

    while (1)
    {
        GPIO_SetPin(PortLED1, PinLED1, 1);
        usleep(dutyHigh); //延时
        GPIO_SetPin(PortLED1, PinLED1, 0);
        usleep(dutyLow); //延时
    }

    GPIO_Free();
}