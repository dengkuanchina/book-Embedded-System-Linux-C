#include "../bsp/bsp_uart.h"

int fdUart1=0;
int fdUart2=0;

char uart1_tx_buf[txSize];
char uart1_rx_buf[rxSize];
char uart2_tx_buf[txSize];
char uart2_rx_buf[rxSize];

void bsp_uart1_Setup()
{
	struct termios options;
	//获取当前串口属性
	tcgetattr( fdUart1,&options);

	//设置输入输出的波特率9600
	cfsetispeed(&options,B9600);
	cfsetospeed(&options,B9600);
	//接收使能
	options.c_cflag |= CLOCAL | CREAD;

	//不使用流控制
	options.c_cflag &= ~CRTSCTS;

	//设置8位数据位
	options.c_cflag &= ~CSIZE;
	options.c_cflag |= CS8;

	//无奇偶校验位
	options.c_cflag &= ~PARENB;
    options.c_iflag &= ~INPCK;

	//设置停止位：1位
	options.c_cflag &= ~CSTOPB;

#if 1 //这是485温湿度计的初始化部分，是否需要？
    options.c_cflag &= ~(INLCR | ICRNL);        //不要回车和换行转换
    options.c_cflag &= ~(IXON | IXOFF | IXANY); //不要软件流控制
#endif

	//修改输出模式，原始数据输出
	options.c_oflag &= ~OPOST;
	options.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG);
	//options.c_lflag &= ~(ISIG | ICANON);

    //设置等待时间和最小接收字符
    options.c_cc[VTIME] = 1; /* 读取一个字符等待1*(1/10)s */
    options.c_cc[VMIN] = 1; /* 读取字符的最少个数为1 */

    //刷新串口缓存
    tcflush(fdUart1,TCIOFLUSH);
	
	//设置新的属性到串口文件
	tcsetattr(fdUart1,TCSANOW,&options); 
}

void bsp_uart2_Setup()
{
	struct termios options;
	//获取当前串口属性
	tcgetattr( fdUart2,&options);

	//设置输入输出的波特率4800
	cfsetispeed(&options,B4800);
	cfsetospeed(&options,B4800);
	//接收使能
	options.c_cflag |= CLOCAL | CREAD;

	//不使用流控制
	options.c_cflag &= ~CRTSCTS;

	//设置8位数据位
	options.c_cflag &= ~CSIZE;
	options.c_cflag |= CS8;

	//无奇偶校验位
	options.c_cflag &= ~PARENB;
    options.c_iflag &= ~INPCK;

	//设置停止位：1位
	options.c_cflag &= ~CSTOPB;

#if 1 //这是485温湿度计的初始化部分，是否需要？
    options.c_cflag &= ~(INLCR | ICRNL);        //不要回车和换行转换
    options.c_cflag &= ~(IXON | IXOFF | IXANY); //不要软件流控制
#endif

	//修改输出模式，原始数据输出
	options.c_oflag &= ~OPOST;
	options.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG);
	//options.c_lflag &= ~(ISIG | ICANON);

    //设置等待时间和最小接收字符
    options.c_cc[VTIME] = 1; /* 读取一个字符等待1*(1/10)s */
    options.c_cc[VMIN] = 1; /* 读取字符的最少个数为1 */

    //刷新串口缓存
    tcflush(fdUart2,TCIOFLUSH);
	
	//设置新的属性到串口文件
	tcsetattr(fdUart2,TCSANOW,&options); 
}
