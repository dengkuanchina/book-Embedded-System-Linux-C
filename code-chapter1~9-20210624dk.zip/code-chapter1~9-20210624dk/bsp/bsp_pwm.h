#ifndef __BSP_PWM_H__
#define __BSP_PWM_H__

#include <stdio.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#define PIO_BASE_ADDR 0x01C20800 //unsigned int 4字节 一个PIO_Struct占36字节,对应十六进制就是0x24，正好是一个offset值
#define PIO_ADDR_OFF 0x800
#define PWM_ADDR_OFF 0x1400
#define PIO_CFG_OFF 0x24
#define PIO_DAT_OFF 0x34
#define PWM_CH0_OFF 0x04
#define PWM_CH1_OFF 0x08



void PWM0_Init(void);
void PWM0_Config(unsigned int pwm_cycle, unsigned int pwm_duty);
void PWM0_UnInit(void);

void PWM1_Init(void);
void PWM1_Config(unsigned int pwm_cycle, unsigned int pwm_duty);
void PWM1_UnInit(void);

#endif
