#include "../bsp/bsp_gpio.h"
#include "../bsp/bsp_spi.h"

//功能： 测试SPI读取ADXL345器件ID(0Xe5)，使用逻辑分析仪测试读取数据是否正确
//spi模式3 CPOL=1;CPHA=1

void SPI_Init(char cMode)
{
    GPIO_Init();

    GPIO_ConfigPinMode(PortCS, PinCS, OUT);
    GPIO_ConfigPinMode(PortSCK, PinSCK, OUT);
    GPIO_ConfigPinMode(PortMOSI, PinMOSI, OUT);
    GPIO_ConfigPinMode(PortMISO, PinMISO, IN);

    GPIO_SetPin(PortCS, PinCS, 1);

    switch (cMode)
    {
    case 0: //使用的spi模式0，初始时钟线(SCK)为低电平
    case 1:
        GPIO_SetPin(PortSCK, PinSCK, 0); //使用的spi模式1，初始时钟线(SCK)为低电平
        break;

    case 2: //使用的spi模式2，初始时钟线(SCK)为高电平
    case 3:
        GPIO_SetPin(PortSCK, PinSCK, 1); //使用的spi模式3，初始时钟线(SCK)为高电平

        break;

    default:
        break;
    }
}

unsigned char SPI_mode0_RWByte(unsigned char u8DataIn)
{
    int i = 0;
    unsigned char u8DataOut = 0;

    for (i = 0; i < 8; i++)
    {
        GPIO_SetPin(PortSCK, PinSCK, 0);
        usleep(10);

        //写数据
        if ((u8DataIn & 0x80) == 0x80) //从高位发送
        {
            GPIO_SetPin(PortMOSI, PinMOSI, 1);
        }
        else
        {
            GPIO_SetPin(PortMOSI, PinMOSI, 0);
        }

        u8DataIn <<= 1;
        u8DataOut <<= 1;

        //读取数据
        if (GPIO_GetPin(PortMISO, PinMISO) != 0) //读取从设备发送的数据
        {
            u8DataOut |= 0x01;
        }
        else
        {
            u8DataOut |= 0x00;
        }

        usleep(10);
        GPIO_SetPin(PortSCK, PinSCK, 1); //将时钟线拉高，在时钟上升沿，数据发送到从设备
        usleep(10);
    }
    GPIO_SetPin(PortSCK, PinSCK, 0);
    return u8DataOut; //返回读取到的数据
}
unsigned char SPI_mode1_RWByte(unsigned char u8DataIn)
{
    int i = 0;
    unsigned char u8DataOut = 0;

    for (i = 0; i < 8; i++)
    {
        GPIO_SetPin(PortSCK, PinSCK, 1);
        usleep(10);

        //写数据
        if ((u8DataIn & 0x80) == 0x80) //从高位发送
        {
            GPIO_SetPin(PortMOSI, PinMOSI, 1);
        }
        else
        {
            GPIO_SetPin(PortMOSI, PinMOSI, 0);
        }

        u8DataIn <<= 1;
        u8DataOut <<= 1;

        //读取数据
        if (GPIO_GetPin(PortMISO, PinMISO) != 0) //读取从设备发送的数据
        {
            u8DataOut |= 0x01;
        }
        else
        {
            u8DataOut |= 0x00;
        }

        usleep(10);
        GPIO_SetPin(PortSCK, PinSCK, 0); //将时钟线拉低，在时钟下降沿，数据发送到从设备
        usleep(10);
    }

    return u8DataOut; //返回读取到的数据
}
unsigned char SPI_mode2_RWByte(unsigned char u8DataIn)
{
    int i = 0;
    unsigned char u8DataOut = 0;

    for (i = 0; i < 8; i++)
    {
        GPIO_SetPin(PortSCK, PinSCK, 1);
        usleep(10);

        //写数据
        if ((u8DataIn & 0x80) == 0x80) //从高位发送
        {
            GPIO_SetPin(PortMOSI, PinMOSI, 1);
        }
        else
        {
            GPIO_SetPin(PortMOSI, PinMOSI, 0);
        }

        u8DataIn <<= 1;
        u8DataOut <<= 1;

        //读取数据
        if (GPIO_GetPin(PortMISO, PinMISO) != 0) //读取从设备发送的数据
        {
            u8DataOut |= 0x01;
        }
        else
        {
            u8DataOut |= 0x00;
        }

        usleep(10);
        GPIO_SetPin(PortSCK, PinSCK, 0); //将时钟线拉低，在时钟下降沿，数据发送到从设备
        usleep(10);
    }
    GPIO_SetPin(PortSCK, PinSCK, 1);

    return u8DataOut; //返回读取到的数据
}

unsigned char SPI_mode3_RWByte(unsigned char u8DataIn)
{
    int i = 0;
    unsigned char u8DataOut = 0;

    for (i = 0; i < 8; i++)
    {
        GPIO_SetPin(PortSCK, PinSCK, 0);
        usleep(10);

        //写数据
        if ((u8DataIn & 0x80) == 0x80) //从高位发送
        {
            GPIO_SetPin(PortMOSI, PinMOSI, 1);
        }
        else
        {
            GPIO_SetPin(PortMOSI, PinMOSI, 0);
        }

        u8DataIn <<= 1;
        u8DataOut <<= 1;

        //读取数据
        if (GPIO_GetPin(PortMISO, PinMISO) != 0) //读取从设备发送的数据
        {
            u8DataOut |= 0x01;
        }
        else
        {
            u8DataOut |= 0x00;
        }

        usleep(10);
        GPIO_SetPin(PortSCK, PinSCK, 1); //将时钟线拉高，在时钟上升沿，数据发送到从设备
        usleep(10);
    }

    return u8DataOut; //返回读取到的数据
}