#ifndef __BSP_SPI_H
#define __BSP_SPI_H

#include <string.h>
#include <stdio.h>
#include <stdint.h>

#include "../bsp/bsp_gpio.h"

#define PortCS      PC
#define PinCS       2
#define PortMISO    PC
#define PinMISO     0
#define PortMOSI    PC
#define PinMOSI     3
#define PortSCK     PC
#define PinSCK      1

void SPI_Init(char cMode);
unsigned char SPI_mode0_RWByte(unsigned char u8DataIn);
unsigned char SPI_mode1_RWByte(unsigned char u8DataIn);
unsigned char SPI_mode2_RWByte(unsigned char u8DataIn);
unsigned char SPI_mode3_RWByte(unsigned char u8DataIn);


#endif