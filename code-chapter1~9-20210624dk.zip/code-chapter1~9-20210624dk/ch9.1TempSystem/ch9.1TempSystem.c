//串口相关的头文件
//还需要的部分：EEPROM读写，和校验，补码转换
//优化函数参数，写成结构体便于理解
#include "../includeAll.h" /*标准输入输出定义*/
#define PortLED1 PG        //LED报警
#define PinLED1 3
#define PortBEEP PG //蜂鸣器报警
#define PinBEEP 4
#define KEY_ID PG //开机设定ID
#define PortKEY 5
#define KEY_warring PG //结束报警
#define PortKEY 6

//初始化读取EEPROM内的ID和阈值
int Thresold_Init(THData *thdata)
{
    ; //添加EEPROM读取程序
}

//LED和BEEP报警，按键处理结束
int LEDBEEPwarring()
{
    for (int i = 0; i < 1000; i++)
    {
        GPIO_SetPin(PortBEEP, PinBEEP, 1);
        usleep(4500);
        GPIO_SetPin(PortBEEP, PinBEEP, 0);
        usleep(500);
    };
    GPIO_SetPin(PortLED1, PinLED1, 1);
    //添加蜂鸣器和LED闪烁
}

int main(void)
{
    //初始化
    int j;
    int temp;
    int cWarningState = 0, cWarringKeyEnable = 1;
    int key;
    THData thdata;
    thdata.nSetID_Flag = 0;

    GPIO_Init();
    GPIO_ConfigPinMode(PortLED1, PinLED1, OUT);
    GPIO_ConfigPinMode(PortBEEP, PinBEEP, OUT);
    GPIO_ConfigPinMode(PortKEY, KEY_ID, IN);      //key
    GPIO_ConfigPinMode(PortKEY, KEY_warring, IN); //key

    Thresold_Init(&thdata); //初始化读取ID，温度湿度阈值
    fdUart2 = open(pathUart2, O_RDWR | O_NOCTTY | O_NDELAY);
    driver_TemAndHum_init(fdUart2);

    //------------------开机按住按键进入设定ID状态----------
    key = GPIO_GetPin(PortKEY, KEY_ID);
    if (key == 0)
    {
        thdata.nSetID_Flag = 1;
        while (1)
        {
            if (Read_From_Master(&thdata) == 0)
            {
                if (thdata.nCode == CmdCode_Change_ID)
                {
                    //写id到eeprom
                    Write_To_Master(&thdata); //如果是发送给本机才需要回传
                    break;
                }
            }
        }
        thdata.nSetID_Flag = 0;
    }

    //----------------------------
    while (1)
    {
        key = GPIO_GetPin(PortKEY, KEY_ID);
        if (key == 0)
        {
            cWarringKeyEnable = 0;
        }

        temp = Read_data(&temperature, &humidity); //读取温湿度,使用dht11
        if (temp == 1)
        {
            printf("read temperature and humidity error!\n");
        }
        else
        {
            printf("read temperature and humidity is: %2.1f,%2.1f\n", (float)temperature / 10.0, (float)humidity / 10.0);
            //添加OLED显示温湿度
        }

        //超过阈值报警，按键结束报警
        if ((temperature > thdata.TemperatureUp) || (temperature < thdata.TemperatureDown) || (humidity > thdata.HumidityUp) || (humidity < thdata.HumidityDown))
        {
            cWarningState = 1;
        }

        if (cWarningState != 0)
        {
            if (cWarringKeyEnable != 0) //没有按键按下
            {
                LedBeepWarring();
                printf("warring!!\n");
            }
            else
            {
                //关闭声光报警的代码
                cWarringKeyEnable = 0;
            }
        }

        //监听串口
        if (Read_From_Master(&thdata) == 0)
        {
            Write_To_Master(&thdata); //如果是发送给本机才需要回传
        }

        //屏幕显示

        sleep(5);
    }

    close(fdUart2);
    return 0;
}
