#include "../includeAll.h"
//用法: time ./pwm_hardware 100 50
//PWM1时钟为100khz，所以100设置的频率是1khz，对应的周期是1ms，50代表100个脉冲中50个是高电平，所以此时占空比是50%

int main(int argc, char *argv[])
{
    int cycle, duty;
    cycle = atoi(argv[1]);
    duty = atoi(argv[2]);
    printf("argv[1] is cycle =%d;--argv[2] is duty =%d\n", cycle, duty);

    PWM1_Init();
    PWM1_Config(cycle, duty);//定义PWM1端口的占空比和频率
    sleep(10);
    
    PWM1_UnInit();
    return 0;
}
