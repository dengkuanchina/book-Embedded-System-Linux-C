#include "../includeAll.h"
#define PortLED0 PG
#define PinLED0 5
#define PortLED1 PG
#define PinLED1 4
#define PortLED2 PG
#define PinLED2 3
/*******************************************************************
 *注意：在bsp_uart.c文件中进行如下设置。串口1接蓝牙模块，波特率为9600bps；串口2接485温湿度模块，波特率为4800bps
*******************************************************************/
void InitAll() 
{
    fdUart1 = open(pathUart1, O_RDWR | O_NOCTTY | O_NDELAY);
    fdUart2 = open(pathUart2, O_RDWR | O_NOCTTY | O_NDELAY);

    GPIO_Init();
    GPIO_ConfigPinMode(PortLED0, PinLED0, OUT);
    GPIO_ConfigPinMode(PortLED1, PinLED1, OUT);
    GPIO_ConfigPinMode(PortLED2, PinLED2, OUT);

    bsp_uart1_Setup(fdUart1);
    driver_Bluetooth_AT();
    driver_Bluetooth_AT_NAME();
    driver_Bluetooth_AT_STAT();
    driver_Bluetooth_AT_NAME_Setup("JDY-33-SPP1234\r\n");
    driver_Bluetooth_AT_RESET();

    bsp_uart2_Setup(fdUart2);
}

int main(int argc, char **argv)
{
    int temperature, humidity, temp;

    InitAll();

    //-------------------------
    while (1)
    {
        temp = driver_read_temperature(&temperature, &humidity);
        if (temp == 1)
        {
            printf("read temperature and humidity error!\n");
        }
        else
        {
            char stringTemp[200];
            sprintf(stringTemp, "read temperature and humidity is: %2.1f,%2.1f\n", (float)temperature / 10.0, (float)humidity / 10.0);
            printf(stringTemp);
            driver_Bluetooth_AT_SendData(stringTemp);
        }

        {
            int len = 0;
            memset(uart1_rx_buf, 0, sizeof(uart1_rx_buf)); //清除串口缓存
            len = driver_Bluetooth_AT_ReceiveData();
            if (len > 0)
            {
                uart1_rx_buf[len] = '\0';
                printf("receive data is: %s\n", uart1_rx_buf);
                switch (uart1_rx_buf[0])
                {
                case '0':
                    GPIO_SetPin(PortLED0, PinLED0, 0);
                    GPIO_SetPin(PortLED1, PinLED1, 1);
                    GPIO_SetPin(PortLED2, PinLED2, 1);
                    break;
                case '1':
                    GPIO_SetPin(PortLED0, PinLED0, 1);
                    GPIO_SetPin(PortLED1, PinLED1, 0);
                    GPIO_SetPin(PortLED2, PinLED2, 1);
                    break;
                case '2':
                    GPIO_SetPin(PortLED0, PinLED0, 1);
                    GPIO_SetPin(PortLED1, PinLED1, 1);
                    GPIO_SetPin(PortLED2, PinLED2, 0);
                    break;
                default:
                    GPIO_SetPin(PortLED0, PinLED0, 1);
                    GPIO_SetPin(PortLED1, PinLED1, 1);
                    GPIO_SetPin(PortLED2, PinLED2, 1);
                    break;
                }
            }
        }

        sleep(1);
    }

    close(fdUart2);
    return 0;
}
