#include "../includeAll.h"

#define Vref 3300

//生成锯齿波
void main(void)
{
    unsigned char Vout = 0x00;
    
    I2C_Init();
    
    while (1)
    {
        PCF8591_DAC_Output(Vout);
        printf("DAC value ：%d mV\n", Vout * Vref / 255);
        Vout = Vout+5;
        if (Vout > 200)
            Vout = 0;
        usleep(1000 * 50);
    }
}
