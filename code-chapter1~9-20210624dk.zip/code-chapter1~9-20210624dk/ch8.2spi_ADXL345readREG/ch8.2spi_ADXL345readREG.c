#include "../includeAll.h"

int main(void)
{
    unsigned char cID = 0;

    SPI_Init(3);

    //adxl345_readID(&cID);
    cID=adxl345_RegRead(0x00);
    printf("chip ID=0x%x\n", cID);
    
    adxl345_RegRead(0x01);

    return 0;
}
