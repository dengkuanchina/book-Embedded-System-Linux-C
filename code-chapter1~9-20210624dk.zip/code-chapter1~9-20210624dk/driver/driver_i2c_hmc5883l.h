#ifndef __DRIVER_Hmc5883l_H
#define __DRIVER_Hmc5883l_H

#include "../includeAll.h"


//-----------------QMC5883L接口函数----------------
unsigned char QMC5883L_Read_Byte(unsigned char reg);
void QMC_Write_Byte(unsigned char val, unsigned char reg);
#define QMC_ADDR 0X0D
#define QMC_XL_REG 0X00
#define QMC_XH_REG 0X01
#define QMC_YL_REG 0X02
#define QMC_YH_REG 0X03
#define QMC_ZL_REG 0X04
#define QMC_ZH_REG 0X05

#define QMC_STATUS_REG 0X06
#define QMC_TEMPL_REG 0X07
#define QMC_TEMPH_REG 0X08
#define QMC_CONTROL1_REG 0X09
#define QMC_CONTROL2_REG 0X0A
#define QMC_RESET_REG 0X0B
//#define QMC_REG              0X0C
#define QMC_ID_REG 0X0D
#endif
