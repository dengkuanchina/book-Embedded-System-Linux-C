#include "../includeAll.h"

// void driver_Lora_init(int fd)
// {
//     struct termios options;
//     //获取当前串口属性
//     tcgetattr(fd, &options);

//     //设置输入输出的波特率9600
//     cfsetispeed(&options, B9600);
//     cfsetospeed(&options, B9600);
//     //接收使能
//     options.c_cflag |= CLOCAL | CREAD;

//     //不使用流控制
//     options.c_cflag &= ~CRTSCTS;

//     //设置8位数据位
//     options.c_cflag &= ~CSIZE;
//     options.c_cflag |= CS8;

//     //无奇偶校验位
//     options.c_cflag &= ~PARENB;
//     options.c_iflag &= ~INPCK;

//     //设置停止位：1位
//     options.c_cflag &= ~CSTOPB;

//     //修改输出模式，原始数据输出
//     options.c_oflag &= ~OPOST;
//     options.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG);
//     //options.c_lflag &= ~(ISIG | ICANON);

//     //设置等待时间和最小接收字符
//     options.c_cc[VTIME] = 1; /* 读取一个字符等待1*(1/10)s */
//     options.c_cc[VMIN] = 1;  /* 读取字符的最少个数为1 */

//     //刷新串口缓存
//     tcflush(fd, TCIOFLUSH);

//     //设置新的属性到串口文件
//     tcsetattr(fd, TCSANOW, &options);
// }

int driver_Lora_AT(void) //发送“+++”，打开AT连接，返回“+OK”表示正常
{
    char *uart1_Lora_tx_buf = "+++";
    int len = 0;

    len = write(fdUart1, uart1_Lora_tx_buf, strlen(uart1_Lora_tx_buf));
    if (len == strlen(uart1_Lora_tx_buf))
        printf("send command is: %s\n", uart1_Lora_tx_buf);
    else
        printf("send data failed!\n");
    sleep(1);

    memset(uart1_Lora_rx_buf, 0, sizeof(uart1_Lora_rx_buf)); //清除串口缓存
    len = read(fdUart1, uart1_Lora_rx_buf, Lora_rxSize - 1);
    if (len > 0)
    {
        uart1_Lora_rx_buf[len] = '\0';
        printf("uart1 receive data: %s", uart1_Lora_rx_buf);

        if (strstr(uart1_Lora_rx_buf, "OK") != NULL)
        {
            return 0;
        }
        else
        {
            printf("Bluetooth responds error!\n");
            return 1;
        }
    }
    else
    {
        printf("Bluetooth AT failed!\n");
        return 1;
    }
}

int driver_Lora_ATT(void) //发送“ATT”，关闭配置模式
{
    char *uart1_Lora_tx_buf = "ATT\r\n";
    int len = 0;

    len = write(fdUart1, uart1_Lora_tx_buf, strlen(uart1_Lora_tx_buf));
    if (len == strlen(uart1_Lora_tx_buf))
        printf("send command is: %s", uart1_Lora_tx_buf);
    else
        printf("send data failed!\n");
    sleep(1);

    memset(uart1_Lora_rx_buf, 0, sizeof(uart1_Lora_rx_buf)); //清除串口缓存
    len = read(fdUart1, uart1_Lora_rx_buf, Lora_rxSize - 1);
    if (len > 0)
    {
        uart1_Lora_rx_buf[len] = '\0';
        printf("uart1 receive data: %s", uart1_Lora_rx_buf);

        if (strstr(uart1_Lora_rx_buf, "OK") != NULL)
        {
            return 0;
        }
        else
        {
            printf("Bluetooth responds error!\n");
            return 1;
        }
    }
    else
    {
        printf("Bluetooth AT failed!\n");
        return 1;
    }
}

int driver_Lora_AT_CFG(void) //查询Lora状态
{
    char *uart1_Lora_tx_buf = "AT+CFG?\r\n";
    int len = 0;

    len = write(fdUart1, uart1_Lora_tx_buf, strlen(uart1_Lora_tx_buf));
    if (len == strlen(uart1_Lora_tx_buf))
        printf("send command is: %s", uart1_Lora_tx_buf);
    else
        printf("send data failed!\n");
    sleep(1);

    memset(uart1_Lora_rx_buf, 0, sizeof(uart1_Lora_rx_buf)); //清除串口缓存
    len = read(fdUart1, uart1_Lora_rx_buf, Lora_rxSize - 1);
    if (len > 0)
    {
        uart1_Lora_rx_buf[len] = '\0';
        printf("uart1 receive data: \n%s", uart1_Lora_rx_buf);
    }
    else
    {
        printf("Bluetooth AT+CFG failed\n");
        return 1;
    }
}

int driver_Lora_AT_NET(char Param[]) //AT+NET=00，node to node；=01，node to gateway
{
    char uart1_Lora_tx_buf[Lora_txSize] = "AT+NET=";
    int len = 0;

    strcat(uart1_Lora_tx_buf, Param);
    len = write(fdUart1, uart1_Lora_tx_buf, strlen(uart1_Lora_tx_buf));
    if (len == strlen(uart1_Lora_tx_buf))
        printf("send command is: %s\n", uart1_Lora_tx_buf);
    else
        printf("send data failed!\n");
    sleep(1);

    memset(uart1_Lora_rx_buf, 0, sizeof(uart1_Lora_rx_buf)); //清除串口缓存
    len = read(fdUart1, uart1_Lora_rx_buf, Lora_rxSize - 1);
    if (len > 0)
    {
        uart1_Lora_rx_buf[len] = '\0';
        printf("uart1 receive data: %s", uart1_Lora_rx_buf);

        if (strstr(uart1_Lora_rx_buf, "OK") != NULL)
        {
            return 0;
        }
        else
        {
            printf("Bluetooth responds error\n");
            return 1;
        }
    }
    else
    {
        printf("Bluetooth AT+NAME setup failed!\n");
        return 1;
    }
}

int driver_Lora_AT_TFREQ(char Param[]) //发送频率
{
    char uart1_Lora_tx_buf[Lora_txSize] = "AT+TFREQ=";
    int len = 0;

    strcat(uart1_Lora_tx_buf, Param);
    len = write(fdUart1, uart1_Lora_tx_buf, strlen(uart1_Lora_tx_buf));
    if (len == strlen(uart1_Lora_tx_buf))
        printf("send command is: %s\n", uart1_Lora_tx_buf);
    else
        printf("send data failed!\n");
    sleep(1);

    memset(uart1_Lora_rx_buf, 0, sizeof(uart1_Lora_rx_buf)); //清除串口缓存
    len = read(fdUart1, uart1_Lora_rx_buf, Lora_rxSize - 1);
    if (len > 0)
    {
        uart1_Lora_rx_buf[len] = '\0';
        printf("uart1 receive data: %s", uart1_Lora_rx_buf);

        if (strstr(uart1_Lora_rx_buf, "OK") != NULL)
        {
            return 0;
        }
        else
        {
            printf("Bluetooth responds error\n");
            return 1;
        }
    }
    else
    {
        printf("Bluetooth AT+NAME setup failed!\n");
        return 1;
    }
}

int driver_Lora_AT_RFREQ(char Param[]) //接收频率
{
    char uart1_Lora_tx_buf[Lora_txSize] = "AT+RFREQ=";
    int len = 0;

    strcat(uart1_Lora_tx_buf, Param);
    len = write(fdUart1, uart1_Lora_tx_buf, strlen(uart1_Lora_tx_buf));
    if (len == strlen(uart1_Lora_tx_buf))
        printf("send command is: %s\n", uart1_Lora_tx_buf);
    else
        printf("send data failed!\n");
    sleep(1);

    memset(uart1_Lora_rx_buf, 0, sizeof(uart1_Lora_rx_buf)); //清除串口缓存
    len = read(fdUart1, uart1_Lora_rx_buf, Lora_rxSize - 1);
    if (len > 0)
    {
        uart1_Lora_rx_buf[len] = '\0';
        printf("uart1 receive data: %s", uart1_Lora_rx_buf);

        if (strstr(uart1_Lora_rx_buf, "OK") != NULL)
        {
            return 0;
        }
        else
        {
            printf("Bluetooth responds error\n");
            return 1;
        }
    }
    else
    {
        printf("Bluetooth AT+NAME setup failed!\n");
        return 1;
    }
}

int driver_Lora_AT_RIQ(char Param[]) //模块接收反转00为关闭，01为打开。
{
    char uart1_Lora_tx_buf[Lora_txSize] = "AT+RIQ=";
    int len = 0;

    strcat(uart1_Lora_tx_buf, Param);
    len = write(fdUart1, uart1_Lora_tx_buf, strlen(uart1_Lora_tx_buf));
    if (len == strlen(uart1_Lora_tx_buf))
        printf("send command is: %s\n", uart1_Lora_tx_buf);
    else
        printf("send data failed!\n");
    sleep(1);

    memset(uart1_Lora_rx_buf, 0, sizeof(uart1_Lora_rx_buf)); //清除串口缓存
    len = read(fdUart1, uart1_Lora_rx_buf, Lora_rxSize - 1);
    if (len > 0)
    {
        uart1_Lora_rx_buf[len] = '\0';
        printf("uart1 receive data: %s", uart1_Lora_rx_buf);

        if (strstr(uart1_Lora_rx_buf, "OK") != NULL)
        {
            return 0;
        }
        else
        {
            printf("Bluetooth responds error\n");
            return 1;
        }
    }
    else
    {
        printf("Bluetooth AT+NAME setup failed!\n");
        return 1;
    }
}

int driver_Lora_AT_SendData(char Data[])
{
    int len = 0;

    len = write(fdUart1, Data, strlen(Data));
    if (len == strlen(Data))
    {
        printf("send data is: %s\n", Data);
        return 0;
    }
    else
    {
        printf("send data failed!\n");
        return 1;
    }

    sleep(1);
}

int driver_Lora_AT_ReceiveData()
{
    int len = 0;
    len = read(fdUart1, uart1_Lora_rx_buf, Lora_rxSize - 1);
    return len;
}