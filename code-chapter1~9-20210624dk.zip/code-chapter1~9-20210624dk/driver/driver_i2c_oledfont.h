#ifndef __DRIVER_I2C_OLEDFONT_H
#define __DRIVER_I2C_OLEDFONT_H 	  
 
//常用ASCII表
//偏移量32
//ASCII字符集
//偏移量32
//大小:12*6

/****************************************8*16的点阵************************************/
unsigned char  F8X16[1520] ;
unsigned char  Hzk[16][32];

#endif


