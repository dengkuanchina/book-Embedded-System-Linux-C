#ifndef __DRIVER_UARTBLUETOOTH_H__
#define __DRIVER_UARTBLUETOOTH_H__

// #include <stdio.h>
// #include <stdlib.h>     /*标准函数库定义*/
// #include <unistd.h>
// #include <sys/mman.h>
// #include <sys/types.h>
// #include <sys/stat.h>
// #include <fcntl.h>
// #include <termios.h>    /*PPSIX 终端控制定义*/
// #include <errno.h>      /*错误号定义*/
// #include <string.h>
// #include <time.h>
// #include <sys/time.h>
// #include <sys/types.h>
// #include <sys/wait.h>
#include "../includeAll.h"

// #define txSize 200
// #define rxSize 200
// #define pathUart1 "/dev/ttyS1"

// extern char uart1_tx_buf[txSize];
// extern char uart1_rx_buf[rxSize];

// void driver_Bluetooth_init(int fd);
int driver_Bluetooth_AT(void);//AT,返回值为0代表成功，返回值为1代表失败
int driver_Bluetooth_AT_STAT(void);//ATSTAT
int driver_Bluetooth_AT_NAME(void);//AT+NAME查询
int driver_Bluetooth_AT_NAME_Setup(char Param[]);//AT+NAME(char *)设置
int driver_Bluetooth_AT_RESET(void);//AT+RESET
int driver_Bluetooth_AT_SendData(char data[]);//透传数据
int driver_Bluetooth_AT_ReceiveData(void);//接收数据


#endif
