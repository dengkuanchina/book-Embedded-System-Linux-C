#ifndef __DRIVER_UART485TemAndHum_H__
#define __DRIVER_UART485TemAndHum_H__

// #include <stdio.h>
// #include <stdlib.h>     /*标准函数库定义*/
// #include <unistd.h>
// #include <sys/mman.h>
// #include <sys/types.h>
// #include <sys/stat.h>
// #include <fcntl.h>
// #include <termios.h>    /*PPSIX 终端控制定义*/
// #include <errno.h>      /*错误号定义*/
// #include <string.h>
// #include <time.h>
// #include <sys/time.h>
// #include <sys/types.h>
// #include <sys/wait.h>
#include "../includeAll.h"

// #define txSize 200
// #define rxSize 200
//#define pathUart2 "/dev/ttyS2"

//int fdUart2;
// char uart2_rx_buf[rxSize];

//void driver_TemAndHum_init(int fd);
int driver_read_temperature(int *temperature, int *humidity);   //查询温度


#endif
