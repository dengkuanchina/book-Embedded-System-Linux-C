#ifndef __DRIVER_I2C_PCF8591_H
#define __DRIVER_I2C_PCF8591_H	


#include "../includeAll.h"

unsigned char PCF8591_ADC_Input(unsigned char cChannel,unsigned char *cADCValue);     //返回值是mv的单位。
void PCF8591_DAC_Output(unsigned char DACValue);

#endif