#include "../includeAll.h"

//-----------底层-------------
void Write_I2C_Command(unsigned char I2C_Command)
{
    I2C_Start();
    I2C_Write_Byte(0x78); //Slave address,SA0=0
    I2C_Wait_Ack();
    I2C_Write_Byte(0x00); //write command
    I2C_Wait_Ack();
    I2C_Write_Byte(I2C_Command);
    I2C_Wait_Ack();
    I2C_Stop();
}

void Write_I2C_Data(unsigned char I2C_Data)
{
    I2C_Start();
    I2C_Write_Byte(0x78); //D/C#=0; R/W#=0
    I2C_Wait_Ack();
    I2C_Write_Byte(0x40); //write data
    I2C_Wait_Ack();
    I2C_Write_Byte(I2C_Data);
    I2C_Wait_Ack();
    I2C_Stop();
}

//----------高层---------------
//坐标设置
void OLED_Set_Position(unsigned char x, unsigned char y)
{
    Write_I2C_Command(0xb0 + y);
    Write_I2C_Command(((x & 0xf0) >> 4) | 0x10);
    Write_I2C_Command((x & 0x0f));
}

//清屏函数,清完屏,整个屏幕是黑色的!和没点亮一样!!!
void OLED_Clear(void)
{
    u8 i, n;
    for (i = 0; i < 8; i++)
    {
        OLED_Set_Position(0, i); //设置页地址（0~7）
        for (n = 0; n < 128; n++)
            Write_I2C_Data(0x00);
    } //更新显示
}

//在指定位置显示一个字符,包括部分字符
//x:0~127
//y:0~7
//mode:0,反白显示;1,正常显示
//size:选择字体 16/12
void OLED_ShowChar(u8 x, u8 y, u8 chr)
{
    unsigned char c = 0, i = 0;
    c = chr - ' '; //得到偏移后的值
    if (x > Max_Column - 1)
    {
        x = 0;
        y = y + 2;
    }

    OLED_Set_Position(x, y);
    for (i = 0; i < 8; i++)
        Write_I2C_Data(F8X16[c * 16 + i]);

    OLED_Set_Position(x, y + 1);
    for (i = 0; i < 8; i++)
        Write_I2C_Data(F8X16[c * 16 + i + 8]);
}

//m^n函数
// u32 oled_pow(u8 m, u8 n)
// {
//     u32 result = 1;
//     while (n--)
//         result *= m;
//     return result;
// }

//显示2个数字
//x,y :起点坐标
//len :数字的位数
//size:字体大小
//mode:模式	0,填充模式;1,叠加模式
//num:数值(0~4294967295);
// void OLED_ShowNum(u8 x, u8 y, u32 num, u8 len, u8 size2)
// {
//     u8 t, temp;
//     u8 enshow = 0;
//     for (t = 0; t < len; t++)
//     {
//         temp = (num / oled_pow(10, len - t - 1)) % 10;
//         if (enshow == 0 && t < (len - 1))
//         {
//             if (temp == 0)
//             {
//                 OLED_ShowChar(x + (size2 / 2) * t, y, ' ', size2);
//                 continue;
//             }
//             else
//                 enshow = 1;
//         }
//         OLED_ShowChar(x + (size2 / 2) * t, y, temp + '0', size2);
//     }
// }

//显示一个字符号串
void OLED_ShowString(u8 x, u8 y, u8 *chr)
{
    unsigned char j = 0;
    while (chr[j] != '\0')
    {
        OLED_ShowChar(x, y, chr[j]);
        x += 8;
        if (x > 120)
        {
            x = 0;
            y += 2;
        }
        j++;
    }
}

//初始化SSD1306
void OLED_Init(void)
{
    I2C_Init();
    Write_I2C_Command(0xAE); //--display off
    Write_I2C_Command(0x00); //---set low column address
    Write_I2C_Command(0x10); //---set high column address
    Write_I2C_Command(0x40); //--set start line address
    Write_I2C_Command(0xB0); //--set page address
    Write_I2C_Command(0x81); // contract control
    Write_I2C_Command(0xFF); //--128
    Write_I2C_Command(0xA1); //set segment remap
    Write_I2C_Command(0xA6); //--normal / reverse
    Write_I2C_Command(0xA8); //--set multiplex ratio(1 to 64)
    Write_I2C_Command(0x3F); //--1/32 duty
    Write_I2C_Command(0xC8); //Com scan direction
    Write_I2C_Command(0xD3); //-set display offset
    Write_I2C_Command(0x00); //

    Write_I2C_Command(0xD5); //set osc division
    Write_I2C_Command(0x80); //

    Write_I2C_Command(0xD8); //set area color mode off
    Write_I2C_Command(0x05); //

    Write_I2C_Command(0xD9); //Set Pre-Charge Period
    Write_I2C_Command(0xF1); //

    Write_I2C_Command(0xDA); //set com pin configuartion
    Write_I2C_Command(0x12); //

    Write_I2C_Command(0xDB); //set Vcomh
    Write_I2C_Command(0x30); //

    Write_I2C_Command(0x8D); //set charge pump enable
    Write_I2C_Command(0x14); //

    Write_I2C_Command(0xAF); //--turn on oled panel
}

//-------------------------------------------------------------
//开启OLED显示
// void OLED_Display_On(void)
// {
//     OLED_WR_Byte(0X8D, OLED_CTRL_CMD); //SET DCDC命令
//     OLED_WR_Byte(0X14, OLED_CTRL_CMD); //DCDC ON
//     OLED_WR_Byte(0XAF, OLED_CTRL_CMD); //DISPLAY ON
// }

//关闭OLED显示
// void OLED_Display_Off(void)
// {
//     OLED_WR_Byte(0X8D, OLED_CTRL_CMD); //SET DCDC命令
//     OLED_WR_Byte(0X10, OLED_CTRL_CMD); //DCDC OFF
//     OLED_WR_Byte(0XAE, OLED_CTRL_CMD); //DISPLAY OFF
// }

/***********功能描述：显示显示BMP图片128×64起始点坐标(x,y),x的范围0～127，y为页的范围0～7*****************/
// void OLED_DrawBMP(unsigned char x0, unsigned char y0, unsigned char x1, unsigned char y1, unsigned char BMP[])
// {
//     unsigned int j = 0;
//     unsigned char x, y;

//     if (y1 % 8 == 0)
//         y = y1 / 8;
//     else
//         y = y1 / 8 + 1;
//     for (y = y0; y < y1; y++)
//     {
//         OLED_Set_Position(x0, y);
//         for (x = x0; x < x1; x++)
//         {
//             OLED_WR_Byte(BMP[j++], OLED_CTRL_DATA);
//         }
//     }
// }

//显示汉字
// void OLED_ShowCHinese(u8 x, u8 y, u8 no)
// {
//     u8 t, adder = 0;
//     OLED_Set_Position(x, y);
//     for (t = 0; t < 16; t++)
//     {
//         OLED_WR_Byte(Hzk[2 * no][t], OLED_CTRL_DATA);
//         adder += 1;
//     }
//     OLED_Set_Position(x, y + 1);
//     for (t = 0; t < 16; t++)
//     {
//         OLED_WR_Byte(Hzk[2 * no + 1][t], OLED_CTRL_DATA);
//         adder += 1;
//     }
// }

//---------暂时不用-------------
// void OLED_WR_Byte(unsigned dat, unsigned isCmd) //cmd=0是命令,!=0是数据
// {
//     if (isCmd)
//     {
//         Write_I2C_Data(dat);
//     }
//     else
//     {
//         Write_I2C_Command(dat);
//     }
// }

// void OLED_On(void)
// {
//     u8 i, n;
//     for (i = 0; i < 8; i++)
//     {
//         OLED_WR_Byte(0xb0 + i, OLED_CTRL_CMD); //设置页地址（0~7）
//         OLED_WR_Byte(0x00, OLED_CTRL_CMD);     //设置显示位置—列低地址
//         OLED_WR_Byte(0x10, OLED_CTRL_CMD);     //设置显示位置—列高地址
//         for (n = 0; n < 128; n++)
//             OLED_WR_Byte(1, OLED_CTRL_DATA);
//     } //更新显示
// }