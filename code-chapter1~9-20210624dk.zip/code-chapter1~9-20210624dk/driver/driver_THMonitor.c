#include "../includeAll.h"

//int fdUart2;
enum CmdCode
{
    CmdCode_Change_ID = 0x00,
    CmdCode_Write_threshold,
    CmdCode_Read_threshold,
    CmdCode_Read_data
};

//从上位机读串口协议
int Read_From_Master(THData *thdata);
{
    char uart2_rx_buf[rxSize];
    int len = 0, nWriteIdEnable = 0;

    len = read(fdUart2, uart2_rx_buf, rxSize - 1);
    if (len == 0) //（1）
    {
        printf("receive data failed!\n"); //接收数据为空
        return 1;
    }

    if ((uart2_rx_buf[0] != 0x55) || (uart2_rx_buf[len - 1] != 0xAA)) //（2）
    {
        printf("start or end data error!\n"); //数据头尾错误
        return 1;
    }

    if (Read_check_SUM()) //（3）
    {
        printf("check SUM error!\n"); //和校验错误
        return 1;
    }

    //------------------------------------
    if ((uart2_rx_buf[2] == 0xFF) && (nSetID_Flag == 1)) //（4）
    {
        nWriteIdEnable = 1;
    }
    else if (uart2_rx_buf[2] != thdata->cID)
    {
        //不是发给本机，也不是设置ID
        return 1;
    }

    //------------------------------------
    thdata->nCode = uart2_rx_buf[3];
    //判断命令代码
    switch (thdata->nCode) //（5）
    {
    case CmdCode_Change_ID:
        if (nWriteIdEnable = 1)
        {
            thdata->cID = uart2_rx_buf[4];
            /* code */
        }

        break; //写ID

    case CmdCode_Write_threshold:
        thdata->TemperatureUp = uart2_rx_buf[4];
        thdata->TemperatureDown = uart2_rx_buf[5];
        thdata->HumidityUp = uart2_rx_buf[6];
        thdata->HumidityDown = uart2_rx_buf[7];
        break; //写阈值

    case CmdCode_Read_threshold:

        break; //发送阈值

    case CmdCode_Read_data:

        break; //请求数据

    default:
        break;
    }

    return 0;
}

//写从机返回数据
int Write_To_Master(THData *thdata);
{
    //头部数据一样
    char *ip; //用指针方便写数据包
    char uart2_tx_buf[txSize] ； int i, len = 0;

    ip = &uart2_tx_buf[4];
    uart2_tx_buf[0] = 0x55;                   //（1）
    uart2_tx_buf[2] = thdata->cID;            //（2）
    uart2_tx_buf[3] = (thdata->nCode) | 0x10; //返回命令代码修改（3）

    //返回不同命令，需要写数据长度，数据内容
    switch (thdata->nCode) //（4）
    {
    case Change_ID:
        uart2_tx_buf[1] = 0x06;
        /* code */
        break; //无返回数据
    case Write_threshold:
        uart2_tx_buf[1] = 0x06;
        break; //无返回数据
    case Read_threshold:
        uart2_tx_buf[1] = 0x0A;
        *ip = thdata->TemperatureUp;
        ip++;
        *ip = thdata->TemperatureDown;
        ip++;
        *ip = thdata->HumidityUp;
        ip++;
        *ip = thdata->HumidityDown;
        ip++;
        break; //返回阈值
    case Read_data:
        uart2_tx_buf[1] = 0x08;
        *ip = thdata->temperature;
        ip++;
        *ip = thdata->humidity;
        ip++ ； break; //返回温湿度
    default:
        break;
    }

    *ip = Write_check_SUM(); //写入校验位（5）
    ip++;
    *ip = 0xAA; //写入结束位（6）
    length = ip - uart2_tx_buf;

    len = write(fdUart2, uart2_tx_buf, length); //（7）
    if (len == length)
    {
        printf("uart2 send data:");
        for (i = 0; i < len; i++)
        {
            printf(" 0x%02x", uart2_tx_buf[i]);
        }
        printf("\n");
    }
    else
        printf("send data failed!\n");
}

//写校验和读校验函数还没写
int Read_check_SUM()
{
    ;
}

char Write_check_SUM()
{
    ;
}