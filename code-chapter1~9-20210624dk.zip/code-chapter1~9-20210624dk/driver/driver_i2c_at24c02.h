#ifndef __DRIVER_AT24C02_H
#define __DRIVER_AT24C02_H

// #include <string.h>
// #include <stdio.h>
// #include <stdint.h>

#include "../includeAll.h"

unsigned char AT24C02_WriteOneByte(unsigned short int WriteAddr, unsigned char DataToWrite);
unsigned char AT24C02_ReadOneByte(unsigned short int ReadAddr);

#endif