#include "../includeAll.h"

unsigned char AT24C02_WriteOneByte(unsigned short int WriteAddr, unsigned char DataToWrite)
{
    I2C_Start();

    I2C_Write_Byte(0xA0); //发送器件地址（1010000）,写标志位（0）
    I2C_Wait_Ack();

    I2C_Write_Byte(WriteAddr); //发送写入地址
    I2C_Wait_Ack();

    I2C_Write_Byte(DataToWrite); //发送字节
    I2C_Wait_Ack();

    I2C_Stop(); //产生一个停止条件

    return 0;
}

//在AT24C02指定地址读出一个数据
//ReadAddr:开始读数的地址
//返回值     :读到的数据
unsigned char AT24C02_ReadOneByte(unsigned short int ReadAddr)
{
    unsigned char u8Temp = 0;
    I2C_Start(); //开始条件

    I2C_Write_Byte(0XA0); //发送器件地址（1010000）,写标志位（0）
    I2C_Wait_Ack();

    I2C_Write_Byte(ReadAddr); //发送需要读取地址
    I2C_Wait_Ack();

    I2C_Start();

    I2C_Write_Byte(0xA1); //发送器件地址（1010000），读标志位（1）
    I2C_Wait_Ack();

    u8Temp = I2C_Read_Byte(0); //0：表示不产生应答信号；1：表示产生应答信号

    I2C_Stop(); //产生一个停止条件
    return u8Temp;
}