
// #include "../driver/driver_uartBluetooth.h"


// void driver_Bluetooth_init(int fd)
// {
// 	struct termios options;
// 	//获取当前串口属性
// 	tcgetattr(fd, &options);

// 	//设置输入输出的波特率9600
// 	cfsetispeed(&options, B9600);
// 	cfsetospeed(&options, B9600);
// 	//接收使能
// 	options.c_cflag |= CLOCAL | CREAD;

// 	//不使用流控制
// 	options.c_cflag &= ~CRTSCTS;

// 	//设置8位数据位
// 	options.c_cflag &= ~CSIZE;
// 	options.c_cflag |= CS8;

// 	//无奇偶校验位
// 	options.c_cflag &= ~PARENB;
// 	options.c_iflag &= ~INPCK;

// 	//设置停止位：1位
// 	options.c_cflag &= ~CSTOPB;

// 	//修改输出模式，原始数据输出
// 	options.c_oflag &= ~OPOST;
// 	options.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG);
// 	//options.c_lflag &= ~(ISIG | ICANON);

// 	//设置等待时间和最小接收字符
// 	options.c_cc[VTIME] = 1; /* 读取一个字符等待1*(1/10)s */
// 	options.c_cc[VMIN] = 1;	 /* 读取字符的最少个数为1 */

// 	//刷新串口缓存
// 	tcflush(fd, TCIOFLUSH);

// 	//设置新的属性到串口文件
// 	tcsetattr(fd, TCSANOW, &options);
// }

// int driver_Bluetooth_AT(void)
// {
// 	char *uart1_tx_buf = "AT\r\n";
// 	int len = 0;

// 	len = write(fdUart1, uart1_tx_buf, strlen(uart1_tx_buf));
// 	if (len == strlen(uart1_tx_buf))
// 		printf("send command is: %s\n", uart1_tx_buf);
// 	else
// 		printf("send data failed!\n");
// 	sleep(1);

// 	memset(uart1_rx_buf, 0, sizeof(uart1_rx_buf)); //清除串口缓存
// 	len = read(fdUart1, uart1_rx_buf, rxSize - 1);
// 	if (len > 0)
// 	{
// 		uart1_rx_buf[len] = '\0';
// 		printf("uart1 receive data: %s\n", uart1_rx_buf);

// 		if (strstr(uart1_rx_buf, "+OK") != NULL)
// 		{
// 			return 0;
// 		}
// 		else
// 		{
// 			printf("Bluetooth responds error!\n");
// 			return 1;
// 		}
// 	}
// 	else
// 	{
// 		printf("Bluetooth AT failed!\n");
// 		return 1;
// 	}
// }

// int driver_Bluetooth_AT_STAT(void)
// {
// 	char *uart1_tx_buf = "AT+STAT\r\n";
// 	int len = 0;

// 	len = write(fdUart1, uart1_tx_buf, strlen(uart1_tx_buf));
// 	if (len == strlen(uart1_tx_buf))
// 		printf("send command is: %s\n", uart1_tx_buf);
// 	else
// 		printf("send data failed!\n");
// 	sleep(1);

// 	memset(uart1_rx_buf, 0, sizeof(uart1_rx_buf)); //清除串口缓存
// 	len = read(fdUart1, uart1_rx_buf, rxSize - 1);
// 	if (len > 0)
// 	{
// 		uart1_rx_buf[len] = '\0';
// 		printf("uart1 receive data: %s\n", uart1_rx_buf);

// 		if (strstr(uart1_rx_buf, "+STAT") != NULL)
// 		{
// 			return 0;
// 		}
// 		else
// 		{
// 			printf("Bluetooth responds error\n");
// 			return 1;
// 		}
// 	}
// 	else
// 	{
// 		printf("Bluetooth AT+STAT failed\n");
// 		return 1;
// 	}
// }

// int driver_Bluetooth_AT_NAME(void)
// {
// 	char *uart1_tx_buf = "AT+NAME\r\n";
// 	int len = 0;

// 	len = write(fdUart1, uart1_tx_buf, strlen(uart1_tx_buf));
// 	if (len == strlen(uart1_tx_buf))
// 		printf("send command is: %s\n", uart1_tx_buf);
// 	else
// 		printf("send data failed!\n");
// 	sleep(1);

// 	memset(uart1_rx_buf, 0, sizeof(uart1_rx_buf)); //清除串口缓存
// 	len = read(fdUart1, uart1_rx_buf, rxSize - 1);
// 	if (len > 0)
// 	{
// 		uart1_rx_buf[len] = '\0';
// 		printf("uart1 receive data: %s\n", uart1_rx_buf);

// 		if (strstr(uart1_rx_buf, "+NAME") != NULL)
// 		{
// 			return 0;
// 		}
// 		else
// 		{
// 			printf("Bluetooth responds error\n");
// 			return 1;
// 		}
// 	}
// 	else
// 	{
// 		printf("Bluetooth AT+NAME failed\n");
// 		return 1;
// 	}
// }

// int driver_Bluetooth_AT_NAME_Setup(char Param[])
// {
// 	char uart1_tx_buf[txSize] = "AT+NAME";
// 	int len = 0;

// 	strcat(uart1_tx_buf, Param);
// 	len = write(fdUart1, uart1_tx_buf, strlen(uart1_tx_buf));
// 	if (len == strlen(uart1_tx_buf))
// 		printf("send command is: %s\n", uart1_tx_buf);
// 	else
// 		printf("send data failed!\n");
// 	sleep(2);

// 	memset(uart1_rx_buf, 0, sizeof(uart1_rx_buf)); //清除串口缓存
// 	len = read(fdUart1, uart1_rx_buf, rxSize - 1);
// 	if (len > 0)
// 	{
// 		uart1_rx_buf[len] = '\0';
// 		printf("uart1 receive data: %s\n", uart1_rx_buf);

// 		if (strstr(uart1_rx_buf, "+OK") != NULL)
// 		{
// 			return 0;
// 		}
// 		else
// 		{
// 			printf("Bluetooth responds error\n");
// 			return 1;
// 		}
// 	}
// 	else
// 	{
// 		printf("Bluetooth AT+NAME setup failed!\n");
// 		return 1;
// 	}
// }

// int driver_Bluetooth_AT_RESET(void)
// {
// 	char *uart1_tx_buf = "AT+RESET\r\n";
// 	int len = 0;

// 	len = write(fdUart1, uart1_tx_buf, strlen(uart1_tx_buf));
// 	if (len == strlen(uart1_tx_buf))
// 		printf("send command is: %s\n", uart1_tx_buf);
// 	else
// 		printf("send data failed!\n");
// 	sleep(1);

// 	memset(uart1_rx_buf, 0, sizeof(uart1_rx_buf));
// 	//清除串口缓存
// 	len = read(fdUart1, uart1_rx_buf, rxSize - 1);
// 	if (len > 0)
// 	{
// 		uart1_rx_buf[len] = '\0';
// 		printf("%s\n", uart1_rx_buf);

// 		if (strstr(uart1_rx_buf, "+OK") != NULL)
// 		{
// 			return 0;
// 		}
// 		else
// 		{
// 			printf("Bluetooth responds error\n");
// 			return 1;
// 		}
// 	}
// 	else
// 	{
// 		printf("Bluetooth AT+RESET failed\n");
// 		return 1;
// 	}
// }

// int driver_Bluetooth_AT_SendData(char Data[])
// {
// 	int len = 0;

// 	len = write(fdUart1, Data, strlen(Data));
// 	if (len == strlen(Data))
// 	{
// 		printf("send data is: %s\n", Data);
// 		return 0;
// 	}
// 	else
// 	{
// 		printf("send data failed!\n");
// 		return 1;
// 	}

// 	sleep(1);
// }

// int driver_Bluetooth_AT_ReceiveData()
// {
// 	int len = 0;
// 	len = read(fdUart1, uart1_rx_buf, rxSize - 1);
// 	return len;
// }
