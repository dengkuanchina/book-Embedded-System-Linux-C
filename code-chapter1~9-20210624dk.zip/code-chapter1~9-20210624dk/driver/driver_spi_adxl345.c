#include "../includeAll.h"

// #include <math.h>
float last_x;
float last_y;
float last_z;

//-------------------以下为本文件内的子函数--------------------

unsigned char adxl345_RegRead(unsigned char addr)
{
    unsigned char data = 0;
    GPIO_SetPin(PortCS, PinCS, 0);
    usleep(10);
    SPI_mode3_RWByte(addr | 0x80); //对地址addr读取
    usleep(10);
    data = SPI_mode3_RWByte(0x55); //需发送一个任意字节的数据
    usleep(10);
    GPIO_SetPin(PortCS, PinCS, 1);
    usleep(20);
    return data;
}

unsigned char adxl345_RegWrite(unsigned char addr, unsigned char data)
{
    GPIO_SetPin(PortCS, PinCS, 0); //(1)
    usleep(10);
    SPI_mode3_RWByte(addr  & 0x7F); //对地址addr写入数据data
    usleep(10);
    SPI_mode3_RWByte(data);
    usleep(10);
    GPIO_SetPin(PortCS, PinCS, 1);
    usleep(20);
    return 0;
}

//补码转化函数
float signedIntToFloat(int sInt)
{
    float fData;
    if (sInt > 0x0FFF)
        fData = -(float)((0xFFFF - sInt + 1) * 0.0039f); //负数
    else
        fData = sInt * 0.0039f; //正数
    return fData;
}

//-------------------以下为暴露出来的接口函数--------------------

void adxl345_init(char cMode)
{
    SPI_Init(cMode);
    //********************ADXL345初始化**************************//
    adxl345_RegWrite(0x1e, 0x00); //X 偏移量
    adxl345_RegWrite(0x1f, 0x00); //Y 偏移量
    adxl345_RegWrite(0x20, 0x00); //Z 偏移量
    adxl345_RegWrite(0x31, 0x0b); //测量范围,量程正负16g，13位全分辨率
    adxl345_RegWrite(0x2c, 0x0a); //数据输出速率为100hz，10ms读一次数据
    adxl345_RegWrite(0x2d, 0x08); //低功耗模式     ADXL345自动调节功耗，与输出数据速率成比例，该模式下采样速率降低至12.5hz-400hz
}


unsigned char adxl345_readXYZdata(ADXL345XYZDATA *adxl345xyzData)
{
    float Ax, Ay, Az;
    unsigned char BUF[6];
    double val = 180.0 / PI;

    //三轴加速度数据分别存放在六个不同的寄存器中，都分为低位和高位分别存放
    BUF[0] = adxl345_RegRead(0x32); //0x32存放X轴低位数据
    BUF[1] = adxl345_RegRead(0x33); //0x33存放X轴高位数据
    BUF[2] = adxl345_RegRead(0x34); //0x34存放Y轴低位数据
    BUF[3] = adxl345_RegRead(0x35); //0x35存放Y轴高位数据
    BUF[4] = adxl345_RegRead(0x36); //0x36存放Z轴低位数据
    BUF[5] = adxl345_RegRead(0x37); //0x37存放Z轴高位数据

    //将低位和高位数据整合
    adxl345xyzData->nXdata = ((unsigned int)BUF[1] << 8) + BUF[0];
    adxl345xyzData->nYdata = ((unsigned int)BUF[3] << 8) + BUF[2];
    adxl345xyzData->nZdata = ((unsigned int)BUF[5] << 8) + BUF[4];

    //将补码格式数据转化成浮点数输出
    adxl345xyzData->fXdata = signedIntToFloat(adxl345xyzData->nXdata);
    adxl345xyzData->fYdata = signedIntToFloat(adxl345xyzData->nYdata);
    adxl345xyzData->fZdata = signedIntToFloat(adxl345xyzData->nZdata);

    //------------
    // Ax = adxl345xyzData->nXdata;
    // Ay = adxl345xyzData->nYdata;
    // Az = adxl345xyzData->nZdata;
    // adxl345xyzData->Angel_x = (atan(Ax / sqrt(Ay * Ay + Az * Az))) * val;
    // adxl345xyzData->Angel_y = (atan(Ay / sqrt(Ax * Ax + Az * Az))) * val;
    // adxl345xyzData->Angel_z = (atan(Az / sqrt(Ax * Ax + Ay * Ay))) * val;
    //------------
    Ax = adxl345xyzData->fXdata;
    Ay = adxl345xyzData->fYdata;
    Az = adxl345xyzData->fZdata;
    adxl345xyzData->Angel_x = (atan(Ax/sqrt(Ay * Ay + Az * Az)))/PI*180;
    adxl345xyzData->Angel_y = (atan(Ay/sqrt(Ax * Ax + Az * Az)))/PI*180;
    adxl345xyzData->Angel_z = (atan(sqrt(Ax * Ax + Ay * Ay)/Az))/PI*180;
    
    sleep(1);

    return 0;
}

unsigned char adxl345_IncrementData(ADXL345XYZDATA *adxl345xyzData)
{
    adxl345xyzData->Increment_x = (adxl345xyzData->fXdata - last_x); 
    adxl345xyzData->Increment_y = (adxl345xyzData->fYdata - last_y); 
    adxl345xyzData->Increment_z = (adxl345xyzData->fZdata - last_z); 
}

unsigned char adxl345_LastData(ADXL345XYZDATA *adxl345xyzData)
{
    last_x = (float)(adxl345xyzData->fXdata);
    last_y = (float)(adxl345xyzData->fYdata);
    last_z = (float)(adxl345xyzData->fZdata);
}
