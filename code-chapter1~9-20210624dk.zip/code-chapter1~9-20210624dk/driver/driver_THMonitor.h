#ifndef __DRIVER_THMonotor_H__
#define __DRIVER_THMonotor_H__

#include <stdio.h>
#include <stdlib.h> /*标准函数库定义*/
#include <unistd.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <termios.h> /*PPSIX 终端控制定义*/
#include <errno.h>   /*错误号定义*/
#include <string.h>
#include <time.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/wait.h>
#include "../includeAll.h"

#define txSize 100
#define rxSize 100
#define CmdCode_Change_ID 0x01
int fdUart2;
char uart2_rx_buf[rxSize];

typedef struct
{
    int nSetID_Flag;     //是否有设置ID，有为1，无为0
    int length;          //数据包长度 位数1
    unsigned char cID;   //数据包的从机ID号 位数2
    int nCode;           //命令码     位数3
    int TemperatureUp;   //温度上限
    int TemperatureDown; //温度下限
    int HumidityUp;      //湿度上限
    int HumidityDown;    //湿度下限
    int temperature;     //当前温度
    int humidity;        //当前湿度
} THData;                //温湿度数据结构体

int Read_From_Master(THData *thdata);
int Write_To_Master(THData *thdata);
int Write_check_SUM(); //写入校验
int Read_check_SUM();  //读校验位
#endif