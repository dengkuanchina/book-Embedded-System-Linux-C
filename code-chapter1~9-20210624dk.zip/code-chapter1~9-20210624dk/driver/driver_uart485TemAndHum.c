#include "../includeAll.h"
// int fdUart2;

//-------------------以下为本文件内的子函数--------------------
//补码未处理。。。以后改进
//返回值是实际数值的10倍
void rs485TempAndHumity_convert(char *dataArray, int *temperature, int *humidity)
{
    *humidity = dataArray[0];
    *humidity = (*humidity) << 8;
    *humidity += dataArray[1];

    *temperature = dataArray[2];
    *temperature = (*temperature) << 8;
    *temperature += dataArray[3];
}

//-------------------以下为暴露出来的接口函数--------------------
#if 0
void driver_TemAndHum_init(int fd)
{
    struct termios options;
    //获取当前串口属性
    tcgetattr(fd, &options);

    //设置输入输出的波特率9600
    cfsetispeed(&options, B4800);
    cfsetospeed(&options, B4800);
    //接收使能
    options.c_cflag |= CLOCAL | CREAD;

    //不使用流控制
    options.c_cflag &= ~CRTSCTS;

    //设置8位数据位
    options.c_cflag &= ~CSIZE;
    options.c_cflag |= CS8;

    //无奇偶校验位
    options.c_cflag &= ~PARENB;
    options.c_iflag &= ~INPCK;

    //设置停止位：1位
    options.c_cflag &= ~CSTOPB;

    options.c_cflag &= ~(INLCR | ICRNL);        //不要回车和换行转换
    options.c_cflag &= ~(IXON | IXOFF | IXANY); //不要软件流控制

    //修改输出模式，原始数据输出
    options.c_oflag &= ~OPOST;
    options.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG);
    //options.c_lflag &= ~(ISIG | ICANON);

    //设置等待时间和最小接收字符
    options.c_cc[VTIME] = 1; /* 读取一个字符等待1*(1/10)s */
    options.c_cc[VMIN] = 1;  /* 读取字符的最少个数为1 */

    //刷新串口缓存
    tcflush(fd, TCIOFLUSH);

    //设置新的属性到串口文件
    tcsetattr(fd, TCSANOW, &options);
}
#endif

int driver_read_temperature(int *temperature, int *humidity)
{
    char uart2_tx_buf[txSize] = {0x01, 0x03, 0x00, 0x00, 0x00, 0x02, 0xc4, 0x0b};
    int i, len = 0;

    len = write(fdUart2, uart2_tx_buf, 8);
    if (len == 8)
    {
        printf("uart2 send data:");
        for (i = 0; i < len; i++)
        {
            printf(" 0x%02x", uart2_tx_buf[i]);
        }
        printf("\n");
    }
    else
        printf("send data failed!\n");
    sleep(2);

    memset(uart2_rx_buf, 0, sizeof(uart2_rx_buf)); //清除串口缓存
    len = read(fdUart2, uart2_rx_buf, rxSize - 1);
    if (len > 0)
    {
        printf("uart2 receive data:");
        for (i = 0; i < len; i++)
        {
            printf(" 0x%02x", uart2_rx_buf[i]);
        }
        printf("\n");

        rs485TempAndHumity_convert(&(uart2_rx_buf[3]), temperature, humidity);
        return 0;
    }
    else
    {
        printf("receive data failed!\n");
        return 1;
    }
}
