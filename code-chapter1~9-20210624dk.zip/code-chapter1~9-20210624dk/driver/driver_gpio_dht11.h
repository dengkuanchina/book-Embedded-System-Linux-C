#ifndef __DHT11_H
#define __DHT11_H
#include "../includeAll.h"
#define PortDHT11 PG
#define PinDHT11 3

int test_pin(int nTime);
int DHT11_Read_Bit();
unsigned char DHT11_Read_Byte();
int DHT11_Read_Data(int *temp, int *humi);
int DHT11_Init();
int DHT11_Rst();
int DHT11_Check();

#endif 
