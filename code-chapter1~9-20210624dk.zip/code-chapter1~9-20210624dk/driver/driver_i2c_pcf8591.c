#include "../includeAll.h"

//通过i2c总线提取adc结果
unsigned char PCF8591_ADC_Input(unsigned char cChannel, unsigned char *cADCValue)
{
    unsigned char temp;

    I2C_Start();
    I2C_Write_Byte(0x90); //器件地址(写)1001 0000
    temp = I2C_Wait_Ack();
    if (temp == 1)
    {
        return 1;
    }

    I2C_Write_Byte(cChannel | 0x40); //设置控制字，选择ADC通道  0:0x00  1:0x01  2:0x02  3:0x03
    I2C_Wait_Ack();
    I2C_Stop();

    usleep(50);
    I2C_Start();
    I2C_Write_Byte(0x91); //器件地址(读)1001 0001
    I2C_Wait_Ack();
    *cADCValue = I2C_Read_Byte(1);
    I2C_Read_Byte(0);
    I2C_Stop();

    return 0;
}

void PCF8591_DAC_Output(unsigned char DACValue)
{
    I2C_Start();
    I2C_Write_Byte(0x90); //器件地址(写)1001 0000
    I2C_Wait_Ack();

    I2C_Write_Byte(0x40); //设置控制字   0100 0000 允许模拟输出,不自增单端
    I2C_Wait_Ack();

    I2C_Write_Byte(DACValue); //将要转换的数字量写入
    I2C_Wait_Ack();
    I2C_Stop();
}
