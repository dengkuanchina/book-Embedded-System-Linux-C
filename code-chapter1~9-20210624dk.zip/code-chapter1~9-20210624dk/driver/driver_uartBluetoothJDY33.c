#include "../includeAll.h"

// char uart1_tx_buf[txSize];
// char uart1_rx_buf[rxSize];

int driver_Bluetooth_AT(void)
{
    char *uart1_tx_buf = "AT\r\n";
    int len = 0;

    len = write(fdUart1, uart1_tx_buf, strlen(uart1_tx_buf));
    if (len == strlen(uart1_tx_buf))
        printf("send command is: %s", uart1_tx_buf);
    else
        printf("send data failed!\n");
    sleep(1);

    memset(uart1_rx_buf, 0, sizeof(uart1_rx_buf)); //清除串口缓存
    len = read(fdUart1, uart1_rx_buf, rxSize - 1);
    if (len > 0)
    {
        uart1_rx_buf[len] = '\0';
        printf("uart1 receive data: %s", uart1_rx_buf);

        if (strstr(uart1_rx_buf, "+OK") != NULL)
        {
            return 0;
        }
        else
        {
            printf("Bluetooth responds error!\n");
            return 1;
        }
    }
    else
    {
        printf("Bluetooth AT failed!\n");
        return 1;
    }
}

int driver_Bluetooth_AT_STAT(void)
{
    char *uart1_tx_buf = "AT+STAT\r\n";
    int len = 0;

    len = write(fdUart1, uart1_tx_buf, strlen(uart1_tx_buf));
    if (len == strlen(uart1_tx_buf))
        printf("send command is: %s", uart1_tx_buf);
    else
        printf("send data failed!\n");
    sleep(1);

    memset(uart1_rx_buf, 0, sizeof(uart1_rx_buf)); //清除串口缓存
    len = read(fdUart1, uart1_rx_buf, rxSize - 1);
    if (len > 0)
    {
        uart1_rx_buf[len] = '\0';
        printf("uart1 receive data: %s", uart1_rx_buf);

        if (strstr(uart1_rx_buf, "+STAT") != NULL)
        {
            return 0;
        }
        else
        {
            printf("Bluetooth responds error\n");
            return 1;
        }
    }
    else
    {
        printf("Bluetooth AT+STAT failed\n");
        return 1;
    }
}

int driver_Bluetooth_AT_NAME(void)
{
    char *uart1_tx_buf = "AT+NAME\r\n";
    int len = 0;

    len = write(fdUart1, uart1_tx_buf, strlen(uart1_tx_buf));
    if (len == strlen(uart1_tx_buf))
        printf("send command is: %s", uart1_tx_buf);
    else
        printf("send data failed!\n");
    sleep(1);

    memset(uart1_rx_buf, 0, sizeof(uart1_rx_buf)); //清除串口缓存
    len = read(fdUart1, uart1_rx_buf, rxSize - 1);
    if (len > 0)
    {
        uart1_rx_buf[len] = '\0';
        printf("uart1 receive data: %s", uart1_rx_buf);

        if (strstr(uart1_rx_buf, "+NAME") != NULL)
        {
            return 0;
        }
        else
        {
            printf("Bluetooth responds error\n");
            return 1;
        }
    }
    else
    {
        printf("Bluetooth AT+NAME failed\n");
        return 1;
    }
}

int driver_Bluetooth_AT_NAME_Setup(char Param[])
{
    char uart1_tx_buf[txSize] = "AT+NAME";
    int len = 0;

    strcat(uart1_tx_buf, Param);
    len = write(fdUart1, uart1_tx_buf, strlen(uart1_tx_buf));
    if (len == strlen(uart1_tx_buf))
        printf("send command is: %s", uart1_tx_buf);
    else
        printf("send data failed!\n");
    sleep(2);

    memset(uart1_rx_buf, 0, sizeof(uart1_rx_buf)); //清除串口缓存
    len = read(fdUart1, uart1_rx_buf, rxSize - 1);
    if (len > 0)
    {
        uart1_rx_buf[len] = '\0';
        printf("uart1 receive data: %s", uart1_rx_buf);

        if (strstr(uart1_rx_buf, "+OK") != NULL)
        {
            return 0;
        }
        else
        {
            printf("Bluetooth responds error\n");
            return 1;
        }
    }
    else
    {
        printf("Bluetooth AT+NAME setup failed!\n");
        return 1;
    }
}

int driver_Bluetooth_AT_RESET(void)
{
    char *uart1_tx_buf = "AT+RESET\r\n";
    int len = 0;

    len = write(fdUart1, uart1_tx_buf, strlen(uart1_tx_buf));
    if (len == strlen(uart1_tx_buf))
        printf("send command is: %s", uart1_tx_buf);
    else
        printf("send data failed!\n");
    sleep(1);

    memset(uart1_rx_buf, 0, sizeof(uart1_rx_buf));
    //清除串口缓存
    len = read(fdUart1, uart1_rx_buf, rxSize - 1);
    if (len > 0)
    {
        uart1_rx_buf[len] = '\0';
        printf("%s\n", uart1_rx_buf);

        if (strstr(uart1_rx_buf, "+OK") != NULL)
        {
            return 0;
        }
        else
        {
            printf("Bluetooth responds error\n");
            return 1;
        }
    }
    else
    {
        printf("Bluetooth AT+RESET failed\n");
        return 1;
    }
}

int driver_Bluetooth_AT_SendData(char Data[])
{
    int len = 0;

    len = write(fdUart1, Data, strlen(Data));
    if (len == strlen(Data))
    {
        printf("send data is: %s\n", Data);
        return 0;
    }
    else
    {
        printf("send data failed!\n");
        return 1;
    }

    sleep(1);
}

int driver_Bluetooth_AT_ReceiveData()
{
    int len = 0;
    len = read(fdUart1, uart1_rx_buf, rxSize - 1);
    return len;
}
