#ifndef __DRIVER_UARTLORANODETONODE_H__
#define __DRIVER_UARTLORANODETONODE_H__
 
#include <stdio.h>
#include <stdlib.h>     /*标准函数库定义*/
#include <unistd.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <termios.h>    /*PPSIX 终端控制定义*/
#include <errno.h>      /*错误号定义*/
#include <string.h>
#include <time.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/wait.h>

#define Lora_txSize 500
#define Lora_rxSize 500
#define pathUart2 "/dev/ttyS2"

//int fdUart1;
char uart1_Lora_tx_buf[Lora_txSize];
char uart1_Lora_rx_buf[Lora_rxSize];

//void driver_Lora_init(int fd);
int driver_Lora_AT(void);//发送“+++”，打开AT连接，返回“+OK”表示正常
int driver_Lora_ATT(void);//发送“ATT”，关闭配置模式
int driver_Lora_AT_CFG(void);//查询Lora状态
int driver_Lora_AT_NET(char Param[]);//AT+NET=00，node to node；=01，node to gateway
int driver_Lora_AT_TFREQ(char Param[]);//发送频率
int driver_Lora_AT_RFREQ(char Param[]);//接收频率
int driver_Lora_AT_RIQ(char Param[]);//模块接收反转00为关闭，01为打开。
int driver_Lora_AT_SendData(char data[]);//透传数据
int driver_Lora_AT_ReceiveData(void);//接收数据



#endif
