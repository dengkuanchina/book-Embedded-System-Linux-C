#ifndef __DRIVER_LM75A_H
#define __DRIVER_LM75A_H

#include <string.h>
#include <stdio.h>
#include <stdint.h>
#include "../includeAll.h"



unsigned int LM75A_ReadTemh();
unsigned int LM75A_ReadTeml();
void LM75A_ReadTemTwoByte(unsigned char *temp_buff);

#endif