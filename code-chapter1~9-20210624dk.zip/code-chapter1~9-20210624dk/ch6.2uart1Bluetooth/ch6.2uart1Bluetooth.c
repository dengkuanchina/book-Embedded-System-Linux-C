#include "../includeAll.h"

#define PortLED0 PG
#define PinLED0 5
#define PortLED1 PG
#define PinLED1 4
#define PortLED2 PG
#define PinLED2 3

/*******************************************************************
 * 	串口属性设置：波特率：9600；数据位：8位；停止位：1位；奇偶校验位:无；流控制：无
*******************************************************************/
void InitAll() //初始化UART1串口，初始化IO口，初始化蓝牙，定义蓝牙名称。
{
    fdUart1 = open(pathUart1, O_RDWR | O_NOCTTY | O_NDELAY);

    GPIO_Init();
    GPIO_ConfigPinMode(PortLED0, PinLED0, OUT);
    GPIO_ConfigPinMode(PortLED1, PinLED1, OUT);
    GPIO_ConfigPinMode(PortLED2, PinLED2, OUT);

    bsp_uart1_Setup();
    driver_Bluetooth_AT();
    driver_Bluetooth_AT_NAME();
    driver_Bluetooth_AT_STAT();
    driver_Bluetooth_AT_NAME_Setup("JDY-33-SPP1234\r\n");
    driver_Bluetooth_AT_RESET();
}

int main()
{
    //int fdUart1;
    InitAll();

    while (1)
    {
        int len = 0;
        memset(uart1_rx_buf, 0, sizeof(uart1_rx_buf)); //清除串口缓存
        len = driver_Bluetooth_AT_ReceiveData();
        if (len > 0)
        {
            uart1_rx_buf[len] = '\0';
            printf("receive data is: %s\n", uart1_rx_buf);
            switch (uart1_rx_buf[0])
            {
            case '0':
                GPIO_SetPin(PortLED0, PinLED0, 0);
                GPIO_SetPin(PortLED1, PinLED1, 1);
                GPIO_SetPin(PortLED2, PinLED2, 1);
                break;
            case '1':
                GPIO_SetPin(PortLED0, PinLED0, 1);
                GPIO_SetPin(PortLED1, PinLED1, 0);
                GPIO_SetPin(PortLED2, PinLED2, 1);
                break;
            case '2':
                GPIO_SetPin(PortLED0, PinLED0, 1);
                GPIO_SetPin(PortLED1, PinLED1, 1);
                GPIO_SetPin(PortLED2, PinLED2, 0);
                break;
            default:
                GPIO_SetPin(PortLED0, PinLED0, 1);
                GPIO_SetPin(PortLED1, PinLED1, 1);
                GPIO_SetPin(PortLED2, PinLED2, 1);
                break;
            }
        }
        else
            sleep(1);
    }
    
    GPIO_Free();
    close(fdUart1);
    return 0;
}
