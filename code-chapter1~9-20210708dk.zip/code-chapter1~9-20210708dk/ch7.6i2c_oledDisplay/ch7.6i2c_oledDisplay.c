#include "../includeAll.h"

int main(void)
{
    unsigned char ch1[10] = "12345";
    unsigned char ch2[10] = "67890";
    unsigned char ch3[10] = "abcde";    

    OLED_Init(); //初始化OLED
    OLED_Clear();

    //---------------------------
    OLED_ShowString(0, 0, ch1);
    OLED_ShowString(0, 2, &ch2[0]);
    OLED_ShowString(0, 4, &ch3);
    OLED_ShowString(0, 6, "ABCDE");

    return 0;
}
