#include "../includeAll.h"

void InitAll() //初始化UART1串口，初始化IO口，初始化蓝牙，定义蓝牙名称。
{
    GPIO_Init();
    OLED_Init(); //初始化OLED
    OLED_Clear();

    fdUart1 = open(pathUart1, O_RDWR | O_NOCTTY | O_NDELAY);
    bsp_uart1_Setup();
    driver_Bluetooth_AT_NAME_Setup("JDY-33-SPP1234\r\n");
    driver_Bluetooth_AT_RESET();
}

int main(void)
{
    InitAll();
    unsigned char ch1[16] = "Dian Xin";
    unsigned char ch2[16] = "20210531";
    unsigned char ch3[16] = "ADC";
    unsigned char nResult, tempValue;

    int len = 0;

    //-----------------------
    OLED_ShowString(0, 0, ch1);
    OLED_ShowString(0, 2, ch2);
    OLED_ShowString(0, 4, ch3);
    OLED_ShowString(0, 6, "Awaiting BT data");

    while (1)
    {
        nResult = PCF8591_ADC_Input(0x00, &tempValue);
        if (nResult == 0)
            sprintf(ch3, "Ain:%4dmV,D:%2x\n", tempValue * 3300 / 255,tempValue);
        else
            sprintf(ch3, "Error!", tempValue);
        sleep(1);
        OLED_ShowString(0, 4, ch3);

        //-----------------------
        memset(uart1_rx_buf, 0, sizeof(uart1_rx_buf)); //清除串口缓存
        len = driver_Bluetooth_AT_ReceiveData();
        if ((len <= 16) & (len > 0))
        {
            OLED_ShowString(0, 6, "                ");
            OLED_ShowString(0, 6, uart1_rx_buf);
            printf("%s\n",uart1_rx_buf);    //在xshell显示
        }
    }
    
    close(fdUart1);
    return 0;
}
