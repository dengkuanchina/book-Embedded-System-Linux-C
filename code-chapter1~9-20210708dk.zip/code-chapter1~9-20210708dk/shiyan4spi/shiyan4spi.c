#include "../includeAll.h"
#define PortBEEP PG
#define PinBEEP 4

void sleep_ms(unsigned int secs)
{
    struct timeval tval;
    tval.tv_sec = secs / 1000;
    tval.tv_usec = (secs * 1000) % 1000000;
    select(0, NULL, NULL, NULL, &tval);
}

int main(void)
{
    unsigned char hint1[] = {"acc:"};
    unsigned char hint2[] = {"ANGLE:"};
    unsigned char accData[3][10] = {};
    unsigned char degData[3][10] = {};
    unsigned char BTbuf[70] = {};
    int i;
    float AngThreshold = 70;
    ADXL345XYZDATA adxl345xyzData;

    //---------------------------
    GPIO_Init();
    GPIO_ConfigPinMode(PortBEEP, PinBEEP, OUT);
    GPIO_SetPin(PortBEEP, PinBEEP, 0);

    OLED_Init(); //初始化OLED
    OLED_Clear();
    OLED_ShowString(0, 6, "Start   BT...");

    fdUart1 = open(pathUart1, O_RDWR | O_NOCTTY | O_NDELAY);
    bsp_uart1_Setup();
    driver_Bluetooth_AT();
    driver_Bluetooth_AT_NAME_Setup("Hmy\r\n");
    driver_Bluetooth_AT_RESET();
    adxl345_init(3);

    //---------------------------
    OLED_ShowString(0, 0, hint1);
    OLED_ShowString(64, 0, hint2);

    while (1)
    {
        adxl345_readXYZdata(&adxl345xyzData);

        printf("----------------------\nAcceleration data：\n");
        printf("x=%f,y=%f,z=%f,\n", adxl345xyzData.fXdata, adxl345xyzData.fYdata, adxl345xyzData.fZdata);

        printf("Angle of tilt data：\n");
        printf("x=%f,y=%f,z=%f,\n", adxl345xyzData.Angel_x, adxl345xyzData.Angel_y, adxl345xyzData.Angel_z);
        printf("----------------------\n \n");

        sprintf(accData[0], "x=%2.2f ", adxl345xyzData.fXdata);
        sprintf(accData[1], "y=%2.2f ", adxl345xyzData.fYdata);
        sprintf(accData[2], "z=%2.2f ", adxl345xyzData.fZdata);
        sprintf(degData[0], "X=%2.1f ", adxl345xyzData.Angel_x);
        sprintf(degData[1], "Y=%2.1f ", adxl345xyzData.Angel_y);
        sprintf(degData[2], "Z=%2.1f ", adxl345xyzData.Angel_z);

        OLED_ShowString(0, 2, accData[0]);
        OLED_ShowString(0, 4, accData[1]);
        OLED_ShowString(0, 6, accData[2]);
        OLED_ShowString(64, 2, degData[0]);
        OLED_ShowString(64, 4, degData[1]);
        OLED_ShowString(64, 6, degData[2]);

        snprintf(BTbuf, 70, "\n---------------------------\nAcceleration Data: %s, %s, %s\n", accData[0], accData[1], accData[2]);
        driver_Bluetooth_AT_SendData(BTbuf);
        memset(BTbuf, 0, sizeof(BTbuf)); //清除串口缓存
        snprintf(BTbuf, 70, "\nANGLE Data: %s, %s, %s\n", degData[0], degData[1], degData[2]);
        driver_Bluetooth_AT_SendData(BTbuf);

        if ((adxl345xyzData.Angel_x > AngThreshold) || (adxl345xyzData.Angel_y > AngThreshold) || (adxl345xyzData.Angel_z > AngThreshold))
        {
            for (i = 0; i < 50; i++)
            {
                GPIO_SetPin(PortBEEP, PinBEEP, 1);
                sleep_ms(5);
                GPIO_SetPin(PortBEEP, PinBEEP, 0);
                sleep_ms(5);
            }
        }
        else
        {
            sleep_ms(100);
        }
    }

    return 0;
}
