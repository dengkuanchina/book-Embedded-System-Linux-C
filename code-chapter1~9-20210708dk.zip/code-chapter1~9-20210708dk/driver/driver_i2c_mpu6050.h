#ifndef __DRIVER_mpu6050_H
#define __DRIVER_mpu6050_H

#include "../includeAll.h"

//-----------------MPU6050接口函数----------------
unsigned char MPU_Read_Byte(unsigned char reg);
void MPU_Write_Byte(unsigned char val, unsigned char reg);

#define MPU_ADDR 0x68          //器件地址
#define MPU_DEVICE_ID_REG 0x75 //ID，对应0x68
#define MPU_TEMP_H 0x41        //温度高位
#define MPU_TEMP_L 0x42        //温度低位
#define MPU_MPU605_RA_PWR_MGT_1 0x6B
#define MPU_MPU605_RA_PWR_MGT_2 0x6C
#define MPU605_RA_SMPLRT_DIV 0x19  //采样
#define MPU605_RA_CONFIG 0x1A      //滤波
#define MPU605_RA_CEL_CONFIG 0x1C  //加速度范围
#define MPU605_RA_GYRO_CONFIG 0x1B //陀螺仪范围
#endif
