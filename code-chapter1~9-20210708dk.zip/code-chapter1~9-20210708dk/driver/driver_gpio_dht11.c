#include "../driver/driver_dht11.h"

int DHT11_Init(void)
{
	GPIO_Init();
	GPIO_ConfigPinMode(PortDHT11, PinDHT11, OUT); //DHT11设置为输出
	GPIO_SetPin(PortDHT11, PinDHT11, 1);
}

int DHT11_Rst(void)
{
	GPIO_ConfigPinMode(PortDHT11, PinDHT11, OUT); //DHT11设置为输出
	GPIO_SetPin(PortDHT11, PinDHT11, 0);
	usleep(20000);
	GPIO_SetPin(PortDHT11, PinDHT11, 1);
	usleep(15);
}

int DHT11_Check(void)
{
	//DHT响应，80us低，80us高
	int retry = 0;
	int key;
	GPIO_ConfigPinMode(PortDHT11, PinDHT11, IN); //DHT11设置为输入
	key = GPIO_GetPin(PortDHT11, PinDHT11);
	//printf("%d %d \n", retry,key);
	//抓到第一次低
	while ((key==0) && (retry < 100)) //
	{
		retry++;
		usleep(20);
		key = GPIO_GetPin(PortDHT11, PinDHT11);
		//printf("\n%d %d KK\n", retry,key);
	}
	//printf("\n%d %d \n", retry,key);
	retry = 0;
	//80us低，抓取高
	key = GPIO_GetPin(PortDHT11, PinDHT11);
	//printf("%d %d\n",retry,key);
	while ((key==1) && (retry < 100)) //
	{
		retry++;
		usleep(15);
		key = GPIO_GetPin(PortDHT11, PinDHT11);
	}
	printf("%d %d L\n", retry,key);
	retry = 0;
	//80us高，抓取低
	key = GPIO_GetPin(PortDHT11, PinDHT11);
	while ((key==0) && (retry < 100)) //
	{
		retry++;
		usleep(15);
		key = GPIO_GetPin(PortDHT11, PinDHT11);
	}
	printf("%d %d H\n", retry,key);
	return 0;
}

int DHT11_Read_Bit(void)
{
	//Check函数已经抓到数据头，现在处于低电平，50us低，选择us高
	int retry = 0;
	int key;
	//抓取高
	while (key && retry < 100) //
	{
		retry++;
		usleep(1);
		key = GPIO_GetPin(PortDHT11, PinDHT11);
	}
	retry = 0;
	//抓取低，求出高电平时长
	key = GPIO_GetPin(PortDHT11, PinDHT11);
	while (!key && retry < 100) //
	{
		retry++;
		usleep(1);
		key = GPIO_GetPin(PortDHT11, PinDHT11);
	}

	if (retry > 30)
		return 1;
	else
		return 0;
}

unsigned char DHT11_Read_Byte(void)
{
	uint8_t i;
	unsigned char dat;
	dat = 0;
	for (i = 0; i < 8; i++)
	{
		dat <<= 1;
		dat |= DHT11_Read_Bit();
	}
	return dat;
}

int DHT11_Read_Data(int *temp, int *humi)
{
	int i = 0;
	unsigned char buf[5];
	DHT11_Rst();
	if (DHT11_Check() == 0)
	{
		for (i = 0; i < 5; i++)
		{
			buf[i] = DHT11_Read_Byte();
		}
		if ((buf[0] + buf[1] + buf[2] + buf[3]) == buf[4])
		{
			*humi = buf[0];
			*temp = buf[2];
		}
	}
	else
		return 1;
	return 0;
}
