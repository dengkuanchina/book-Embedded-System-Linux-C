#ifndef __DRIVER_ADXL345_H
#define __DRIVER_ADXL345_H

// #include <string.h>
// #include <stdio.h>
// #include <stdint.h>
//#include <math.h>
#include "../includeAll.h"

//#define NUMMPY 0x55
// #define R1byte 0x80
// #define W1byte 0x00
#define PI 3.14159265

typedef struct
{
  signed nXdata; //16进制补码形式
  signed nYdata;
  signed nZdata;
  double Angel_x;//倾角
  double Angel_y;
  double Angel_z;
  signed Increment_x;//加速度增加幅度
  signed Increment_y;
  signed Increment_z;
  float fXdata;//浮点数加速度数据
  float fYdata;
  float fZdata;
} ADXL345XYZDATA;

//-----------------------------------
//extern ADXL345XYZDATA adxl345xyzData;

//-----------------------------------
unsigned char adxl345_RegRead(unsigned char addr);
unsigned char adxl345_RegWrite(unsigned char addr, unsigned char data);
float signedIntToFloat(int sInt);

void adxl345_init(char cMode);
unsigned char adxl345_readXYZdata(ADXL345XYZDATA *adxl345xyzData);
unsigned char adxl345_IncrementData(ADXL345XYZDATA *adxl345xyzData);
unsigned char adxl345_LastData(ADXL345XYZDATA *adxl345xyzData);

#endif
