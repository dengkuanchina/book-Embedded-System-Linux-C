#include "../includeAll.h"

void LM75A_ReadTemTwoByte(unsigned char *temp_buff)
{
    I2C_Start();
    I2C_Send_Byte(0x90);
    I2C_Wait_Ack();
    I2C_Send_Byte(0x00);
    I2C_Wait_Ack();
      
    I2C_Start();
    I2C_Send_Byte(0x91);
    I2C_Wait_Ack();

    *temp_buff=I2C_Read_Byte(1);
    I2C_Wait_Ack();
    *(temp_buff+1)=I2C_Read_Byte(0);
    I2C_Stop();
}

unsigned int LM75A_ReadTemh()
{
    int temp_buff[2];
    I2C_Start();
    I2C_Send_Byte(0x90);
    I2C_Wait_Ack();
    I2C_Send_Byte(0x00);
    I2C_Wait_Ack();
      
    I2C_Start();
    I2C_Send_Byte(0x91);
    I2C_Wait_Ack();

    temp_buff[0]=I2C_Read_Byte(1);
    I2C_Wait_Ack();
    temp_buff[1]=I2C_Read_Byte(0);
    I2C_Stop();
    return temp_buff[0];
}
unsigned int LM75A_ReadTeml()
{
    int temp_buff[2];
    I2C_Start();
    I2C_Send_Byte(0x90);
    I2C_Wait_Ack();
    I2C_Send_Byte(0x00);
    I2C_Wait_Ack();
      
    I2C_Start();
    I2C_Send_Byte(0x91);
    I2C_Wait_Ack();

    temp_buff[0]=I2C_Read_Byte(1);
    I2C_Wait_Ack();
    temp_buff[1]=I2C_Read_Byte(0);
    I2C_Stop();
    return temp_buff[1];
}