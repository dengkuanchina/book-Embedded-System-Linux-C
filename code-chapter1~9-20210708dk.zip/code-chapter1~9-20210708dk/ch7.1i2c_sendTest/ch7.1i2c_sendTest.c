#include "../includeAll.h"
//#define i2cdelaytime 2
int main(void)
{
    I2C_Init();
    //---------开始信号---------
    I2C_Start();
    //----------写入数据------------
    I2C_Write_Byte(0x01);
    //----------结束信号-----------
    I2C_Stop();
    //-------------------------------
    I2C_UnInit();
    printf("OK\n");

    return 0;
}
