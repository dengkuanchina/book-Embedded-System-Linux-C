#include "../includeAll.h"
#define RecvSize 100

/****************************************
串口属性设置.波特率：115200；数据位：8位；停止位：1位；奇偶校验位:无；流控制：无
*****************************************/
int main(int argc, char **argv)
{
    int i;
    //int fdUart1; //文件描述符
    int len;
    char recv_buf[RecvSize];

    //打开串口，返回文件描述符
    fdUart1 = open(pathUart1, O_RDWR | O_NOCTTY | O_NDELAY);

    //设置串口：波特率，数据位，停止位，奇偶校验位，流控制
    bsp_uart1_Setup(fdUart1);

    while (1)
    {
        memset(recv_buf, 0, sizeof(recv_buf)); //清除串口缓存
        len = read(fdUart1, recv_buf, RecvSize - 1);
        if (len > 0)
        {
            printf("receive data is: %s\n", recv_buf);
            len = write(fdUart1, recv_buf, strlen(recv_buf));
            if (len == strlen(recv_buf))
                printf("send data is ok: %s\n", recv_buf);
            else
                printf("send data failed!\n");
        }
        else
            printf("No receive data! \n");

        sleep(5);
    }
    close(fdUart1);

    return 0;
}
