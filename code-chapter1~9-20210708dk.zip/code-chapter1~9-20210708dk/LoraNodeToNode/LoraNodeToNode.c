#include "../includeAll.h"
//Lora点对点通信
/*******************************************************************
 * 	串口属性设置：波特率：9600；数据位：8位；停止位：1位；奇偶校验位:无；流控制：无
*******************************************************************/
void Init()
{
    extern int fdUart1;
    fdUart1 = open(pathUart1, O_RDWR | O_NOCTTY | O_NDELAY);
    //driver_Lora_init(fdUart1);
    bsp_uart1_Setup(fdUart1);
    sleep(1);
    driver_Lora_AT();
    sleep(1);
    driver_Lora_AT_NET("00\r\n");
    sleep(1);
    driver_Lora_AT_TFREQ("19CF0E40\r\n"); //十六进制表示
    sleep(1);
    driver_Lora_AT_RFREQ("19CF0E40\r\n"); //十六进制表示
    sleep(1);
    driver_Lora_AT_RIQ("00\r\n");
    sleep(1);
    driver_Lora_AT_CFG();
    sleep(1);
    driver_Lora_ATT();
    sleep(1);
}

int main()
{
    Init();
    while (1)
    {
        driver_Lora_AT_SendData("abcd\r\n");
        sleep(1);
    }
    GPIO_Free();
    close(fdUart1);
    return 0;
}
