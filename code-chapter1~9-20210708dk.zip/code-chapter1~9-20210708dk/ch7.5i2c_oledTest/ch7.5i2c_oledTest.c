#include "../includeAll.h"
unsigned char test[8] = {0x1c, 0x32, 0x62, 0x84, 0x84, 0x62, 0x32, 0x1c};
int main(void)
{
    u8 x = 0,y = 0; //OLED坐标

    OLED_Init();     //初始化OLED
    OLED_Clear();    //清除屏幕

    OLED_Set_Position(x, y);
    
    u8 i=0;
    for (i; i < 8; i++) //画图
    {
        Write_I2C_Data(test[i]);
    }
}