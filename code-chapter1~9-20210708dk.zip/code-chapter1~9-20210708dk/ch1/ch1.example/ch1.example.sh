#!/bin/bash 
pwd 
ls -al

echo this is shell

#如果执行时出现/bin/bash^M: bad interpreter: No such file or directory的错误，那是因为文本是dos格式的，以回车和换行做的结束符。用vscode，在右下角，点CRLF，然后选择LF就可以了。
