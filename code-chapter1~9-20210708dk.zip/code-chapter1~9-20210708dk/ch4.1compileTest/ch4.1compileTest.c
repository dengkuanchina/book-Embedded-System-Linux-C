//交叉编译和本地编译的对比
#include "stdio.h"
#include "math.h"

int main()
{
	char ch1[20];
	float i;
	printf("请输入名字：");
	scanf("%s", ch1);
	printf("Hello %s!\n", ch1);
	printf("请输入一个数字:");
	scanf("%f", &i);
	printf("它的平方根是：%f\n", sqrt(i));
	return 0;
}
