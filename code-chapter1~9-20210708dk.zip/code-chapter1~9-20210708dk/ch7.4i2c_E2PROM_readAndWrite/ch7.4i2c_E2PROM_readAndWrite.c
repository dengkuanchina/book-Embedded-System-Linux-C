#include "../includeAll.h"

#define iicdelaytime 2
int main(void)
{
    unsigned char u8temp;

    I2C_Init();
    AT24C02_WriteOneByte(0x34, 0x0A);
    sleep(1); //写一个周期时间最大5ms
    u8temp = AT24C02_ReadOneByte(0x34);
    printf("the data is 0x%x\n", u8temp);
    
    return 0;
}
