#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
//  用法：  ./test3_10fputc
//     运行结果：无显示。然后输入ls命令，可以看到增加了tmp文件。
//         然后，输入cat tmp命令，就会显示abcdefghijklmnopqrstuvwxyz
//     备注：无。
int main()
{
    FILE *fp;
    char a[27] = "abcdefghijklmnopqrstuvwxyz\n";
    int i;
    fp = fopen("tmp", "w"); //注意，路径不能使用~
    if (NULL == fp)
    {
        printf("errno = %d\n", errno); //错误代码2含义：无此文件或目录
        exit(1);
    }
    else
    {
        for (i = 0; i < 27; i++)
            fputc(a[i], fp);
        fclose(fp);
    }
}
