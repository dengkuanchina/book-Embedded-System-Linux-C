#include <stdio.h>
//  用法：clear; ./test3_8fgetc
//     运行结果：显示了test3_8fgetc.c文件的内容
//     注意：无
int main()
{
    FILE *fp;
    int c;
    fp = fopen("ch3.8fgetc.c", "r"); //路径可以使用相对路径，但是不能使用~
    while ((c = fgetc(fp)) != EOF)
        printf("%c", c);
    fclose(fp);
}