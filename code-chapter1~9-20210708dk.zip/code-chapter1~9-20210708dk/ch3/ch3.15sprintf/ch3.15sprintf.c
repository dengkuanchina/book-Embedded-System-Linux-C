#include <stdio.h>
//  用法： ./test3_15sprintf
//     运行结果：
// >>> This is string A!<<<
//     备注：无。
int main()
{
    char *a = "This is string A!";
    char buf[80];
    sprintf(buf, ">>> %s<<<\n", a);
    printf("%s", buf);
}
