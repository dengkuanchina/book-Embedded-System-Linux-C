#include <stdio.h>
//   用法：./test3_7fseek
//     运行结果：
// offset=5
// offset=0
// offset = 10

//     注意：编译时有数据类型不匹配的告警，不影响运行。
int main()
{
    FILE *stream;
    long offset;
    fpos_t pos;
    stream = fopen("/etc/passwd", "r");
    fseek(stream, 5, SEEK_SET);
    printf("offset=%d\n", ftell(stream));
    rewind(stream); //rewind回到文件的起点
    fgetpos(stream, &pos);
    printf("offset=%d\n", pos);
    pos.__pos = 10;
    fsetpos(stream, &pos);
    printf("offset=%d\n", ftell(stream));
    fclose(stream);
}
