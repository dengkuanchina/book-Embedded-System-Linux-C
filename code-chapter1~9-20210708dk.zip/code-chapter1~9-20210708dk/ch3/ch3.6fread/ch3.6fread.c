#include <stdio.h>
//   用法：  ./test3_6fread
//     运行结果：
// sizeof(struct test)=24
// name[0]=Linux!              :size[0]=6
// name[1]=FreeBSD!            :size[1]=8
// name[2]=Windows2000.        :size[2]=12
//     注意：1.tmp文件是例程test3_5fwrite.c产生。如果没有tmp文件，会有段错误的提示。
//     备查知识点：
//     1.printf中使用"%-20s"，代表字符串显示时是左对齐，不足20就在右边用空格补齐20个字符，如果超过20还是会完整显示字符串。
#define nmemb 3
struct test
{
    char name[20];
    int size;
} buffer[nmemb];
int main()
{
    FILE *stream;
    int i;
    i = sizeof(struct test);
    printf("sizeof(struct test)=%d\n", i); //值为
    stream = fopen("tmp", "r");            //注意，路径不能使用~
    fread(buffer, sizeof(struct test), nmemb, stream);
    fclose(stream);
    for (i = 0; i < nmemb; i++)
        printf("name[%d]=%-20s:size[%d]=%d\n", i, buffer[i].name, i, buffer[i].size);
}
