#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <unistd.h> //for read close
#include <fcntl.h>  //for open
#define BUFFER_SIZE 1000
//   用法：./test3_3fileCopy test3_3fileCopy.c new1
//  运行结果：
//  readTimes= 1, read Byte number= 1000
//  readTimes= 2, read Byte number= 1000
//  readTimes= 3, read Byte number= 580
//  注意：1.程序运行后，通过用ls -al显示出new1文件所占的字节大小，是可以确定程序通过几次读写的总数据的大小是正确的。
int main(int argc, char **argv)
{
    int from_fd, to_fd;
    int bytes_read, bytes_write;
    char buffer[BUFFER_SIZE];
    char *ptr;         //pointer指针
    int readTimes = 0; //循环读文件的次数
    if (argc != 3)
    {
        fprintf(stderr, "Usage:%s fromfile tofile/n/a", argv[0]);
        exit(1);
    }
    //打开源文件
    if ((from_fd = open(argv[1], O_RDONLY)) == -1)
    {
        fprintf(stderr, "Open %s Error:%s/n", argv[1], strerror(errno));
        exit(1);
    }
    //创建目的文件
    if ((to_fd = open(argv[2], O_WRONLY | O_CREAT, S_IRUSR | S_IWUSR)) == -1)
    {
        fprintf(stderr, "Open %s Error:%s/n", argv[2], strerror(errno));
        exit(1);
    }
    //以下代码是复制文件的代码
    while (bytes_read = read(from_fd, buffer, BUFFER_SIZE))
    {
        readTimes++;
        printf("readTimes= %d, read Byte number= %d\n", readTimes, bytes_read); //显示循环读的次数

        if ((bytes_read == -1) && (errno != EINTR)) //一个致命的错误发生了
            break;
        else if (bytes_read > 0)
        {
            ptr = buffer;
            while (bytes_write = write(to_fd, ptr, bytes_read))
            {
                if ((bytes_write == -1) && (errno != EINTR)) //一个致命错误发生了
                    break;
                else if (bytes_write == bytes_read) //写完了所有读的字节
                    break;
                else if (bytes_write > 0) //只写了一部分,继续写
                {
                    ptr += bytes_write;
                    bytes_read -= bytes_write;
                }
            }
            if (bytes_write == -1) //写的时候发生的致命错误
                break;
        }
    }
    close(from_fd);
    close(to_fd);
    exit(0);
}
