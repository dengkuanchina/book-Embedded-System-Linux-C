#include <stdio.h>
#include <string.h>
//   用法：  ./test3_11fgets
//     运行结果：
// This is a test
// 然后输入ls命令，可以看到增加了tmp文件。输入cat tmp命令，就会显示This is a test

//     备注：fgets( )用来从参数stream所指的文件内读入字符并存到参数s所指的内存空间，
//         直到出现换行字符、读到文件尾或者已读了size－1个字符为止，最后会加上NULL作为字符串结束.
int main(void)
{
    FILE *stream; //FILE 是一种数据类型，是治理文件流的一种结构
    char string[] = "This is a test\n";
    char msg[20];
    stream = fopen("tmp", "w+"); //打开文件，用于更新文件
    fwrite(string, strlen(string), 1, stream);
    fseek(stream, 0, SEEK_SET); //回到文件开头
    fgets(msg, strlen(string) + 1, stream);
    printf("%s", msg);
    fclose(stream);
    return 0;
}
