#include "../includeAll.h"
#define i2cdelaytime 1

void I2C_Init(void)
{
    GPIO_Init();
}

void I2C_UnInit(void)
{
    GPIO_Free();
}

//主机产生开始条件
void I2C_Start(void)
{
    //---------产生空闲状态---------
    GPIO_ConfigPinMode(PortSDA, PinSDA, OUT);
    GPIO_ConfigPinMode(PortSCL, PinSCL, OUT);
    usleep(i2cdelaytime);

    GPIO_SetPin(PortSDA, PinSDA, 1);
    GPIO_SetPin(PortSCL, PinSCL, 1);
    usleep(i2cdelaytime);
    //---------产生起始信号---------
    GPIO_SetPin(PortSDA, PinSDA, 0);
    usleep(i2cdelaytime);
}

//主机产生停止条件
void I2C_Stop(void)
{
    GPIO_ConfigPinMode(PortSDA, PinSDA, OUT);

    GPIO_SetPin(PortSDA, PinSDA, 0);
    GPIO_SetPin(PortSCL, PinSCL, 1);
    usleep(i2cdelaytime);

    GPIO_SetPin(PortSDA, PinSDA, 1);
    usleep(i2cdelaytime);
}

//主机等待从机产生的应答信号
unsigned char I2C_Wait_Ack(void)
{
    uint16_t u16ErrTime = 0;

    GPIO_ConfigPinMode(PortSDA, PinSDA, IN); //SDA设置为输入
    GPIO_SetPin(PortSCL, PinSCL, 1);
    usleep(i2cdelaytime);

    //等待SDA低电平
    while (GPIO_GetPin(PortSDA, PinSDA) == 1)
    {
        u16ErrTime++;

        if (u16ErrTime > 250)
        {
            I2C_Stop();
            return 1;
        }
    }

    GPIO_SetPin(PortSCL, PinSCL, 0);
    return 0;
}

// IIC Write byte
//主机发送数据到从机
void I2C_Write_Byte(unsigned char txd)
{
    unsigned char t;

    GPIO_ConfigPinMode(PortSDA, PinSDA, OUT);
    GPIO_SetPin(PortSCL, PinSCL, 0);

    for (t = 0; t < 8; t++)
    {
        if ((txd & 0x80) >> 7)
        {
            GPIO_SetPin(PortSDA, PinSDA, 1);
        }
        else
        {
            GPIO_SetPin(PortSDA, PinSDA, 0);
        }

        txd <<= 1;
        usleep(i2cdelaytime);

        GPIO_SetPin(PortSCL, PinSCL, 1);
        usleep(i2cdelaytime);

        GPIO_SetPin(PortSCL, PinSCL, 0);
        usleep(i2cdelaytime);
    }
}

//主机读取从机数据
// ack=0时主机不产生应答信号；ack=1时主机产生应答信号。
unsigned char I2C_Read_Byte(unsigned char ack)
{
    unsigned char i, receive = 0;

    for (i = 0; i < 8; i++)
    {
        GPIO_SetPin(PortSCL, PinSCL, 0);
        usleep(i2cdelaytime);

        GPIO_SetPin(PortSCL, PinSCL, 1);
        receive <<= 1;

        if (GPIO_GetPin(PortSDA, PinSDA))
        {
            receive++;
        }

        usleep(i2cdelaytime);
    }

    if (!ack)
    {
        //不产生应答
        GPIO_SetPin(PortSCL, PinSCL, 0);
        GPIO_ConfigPinMode(PortSDA, PinSDA, OUT);

        GPIO_SetPin(PortSDA, PinSDA, 1);
        usleep(i2cdelaytime);

        GPIO_SetPin(PortSCL, PinSCL, 1);
        usleep(i2cdelaytime);

        GPIO_SetPin(PortSCL, PinSCL, 0);
    }
    else
    {
        //产生应答
        GPIO_SetPin(PortSCL, PinSCL, 0);
        GPIO_ConfigPinMode(PortSDA, PinSDA, OUT);

        GPIO_SetPin(PortSDA, PinSDA, 0);
        usleep(i2cdelaytime);

        GPIO_SetPin(PortSCL, PinSCL, 1);
        usleep(i2cdelaytime);

        GPIO_SetPin(PortSCL, PinSCL, 0);
    }
    return receive;
}