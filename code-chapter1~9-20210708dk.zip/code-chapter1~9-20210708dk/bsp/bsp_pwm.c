#include "bsp_pwm.h"

unsigned int *base_map = NULL;
unsigned int *gpio_map = NULL;
unsigned int *gpio_cfg = NULL;
unsigned int *gpio_dat = NULL;
unsigned int *pwm_base_map = NULL;
unsigned int *pwm0_period = NULL, *pwm1_period = NULL;
unsigned int mem_fd;
unsigned int addr_start, addr_offset;
unsigned int PageSize, PageMask;

void PWM0_Init(void)
{
    if ((mem_fd = open("/dev/mem", O_RDWR)) < 0)
    {
        printf("open error\r\n");
        return;
    }

    PageSize = sysconf(_SC_PAGESIZE); //使用sysconf查询系统页面大小
    PageMask = (~(PageSize - 1));     //页掩码
    //printf("PageSize:%d,PageMask:0x%.8X\r\n", PageSize, PageMask);

    addr_start = PIO_BASE_ADDR & PageMask;   //0x01C20800 & 0xfffff000 =  0x1C20000
    addr_offset = PIO_BASE_ADDR & ~PageMask; //0x01C20800 & 0x00000100 = 0x800
    //printf("addr_start:%.8X,addr_offset:0x%.8X\r\n", addr_start, addr_offset);

    //mmap(系统自动分配内存地址，映射区长度“内存页的整数倍”，选择可读可写，MAP_SHARED=与其他所有映射到这个对象的进程共享空间，文件句柄，被映射内容的起点)
    //offest 映射物理内存的话，必须页对其!!!   所以这个起始地址应该是0x1000的整数倍，那么明显0x01C20800需要减去0x800才是整数倍！
    if ((base_map = (unsigned int *)mmap(NULL, PageSize * 2, PROT_READ | PROT_WRITE, MAP_SHARED, mem_fd, addr_start)) == NULL)
    {
        printf("mmap error\r\n");
        close(mem_fd);
        return;
    }
    //printf("base_map:0x%.8X\n", (unsigned int)base_map);
    close(mem_fd); //映射好之后就可以关闭文件

    //--------------------------------------
    //这里已经将0x1c20000的地址映射到了内存中，但是我们需要的地址是0x01C20800，所以要再加上地址偏移量～
    gpio_map = (unsigned int)base_map + PIO_ADDR_OFF; //加上偏移量必选先把他转化成unsigend int才可以相加
    //printf("gpio_map:0x%.8X\n", (unsigned int)gpio_map);
    gpio_cfg = (unsigned int)gpio_map + PIO_CFG_OFF; //gpioB控制寄存器地址
    //printf("gpio_cfg:0x%.8X\n", (unsigned int)gpio_cfg);
    gpio_dat = (unsigned int)gpio_map + PIO_DAT_OFF; //gpioB数据寄存器地址
    //printf("gpio_dat:0x%.8X\n", (unsigned int)gpio_dat);

    /*PB4点灯*/
    (*gpio_cfg) &= ~((unsigned int)7 << 16); //先将对应位置0
    (*gpio_cfg) |= ((unsigned int)1 << 16);  //PB4 设定out
    (*gpio_dat) &= ~(1 << 4);                //开灯
    //sleep(3);
}

void PWM0_Config(unsigned int pwm_cycle, unsigned int pwm_duty)
{
    //PB4设定PWM输出
    (*gpio_cfg) &= ~((unsigned int)7 << 16);
    (*gpio_cfg) |= ((unsigned int)1 << 17); //PB4 设定PWM0模式
    //我们需要的地址是0x01C21400，所以要再加上地址偏移量
    pwm_base_map = (unsigned int)base_map + PWM_ADDR_OFF; //pwm_base_map也是pwm控制寄存器 初始值是0x00000000
    //printf("pwm_base_map:0x%.8X\n", (unsigned int)pwm_base_map);

    /*首先设置PWM0 预分頻*/                      //PWM_CH0_PRESCAL
    (*pwm_base_map) &= ~((unsigned int)15 << 0); //先将0~3位设置0
    (*pwm_base_map) |= (unsigned int)1 << 1;     //将0～3位设置为 0010 ---> 对应分頻1-->24M/240 Hz
    (*pwm_base_map) &= ~((unsigned int)1 << 5);  //先将第5位设置0
    (*pwm_base_map) |= (unsigned int)1 << 5;     //将第5位设置1 ---> 高电平有效
    /*可能要设置SCLK_CH0_GATING为mask*/
    (*pwm_base_map) &= ~((unsigned int)1 << 6); //先将第6位设置0
    (*pwm_base_map) |= (unsigned int)1 << 6;    //将第6位设置1 ---> 设置为自定义预分頻系数

    /*再设置pwm0占空比*/
    pwm0_period = (unsigned int)pwm_base_map + PWM_CH0_OFF; //pwm0_period设置pwm_ch0的占空比寄存器
    //printf("pwm0_period:0x%.8X\n", (unsigned int)pwm0_period);

    /*先设置总周期*/                                //PWM周期的计算应该是这样 OSC 24MHz / Pre-scalar / (entire cycles + 1)
    (*pwm0_period) &= ~((unsigned int)65535 << 16); //将31～16位设置零
    //24Mhz / 240 / (pwm_cycle+1)
    (*pwm0_period) |= (unsigned int)(pwm_cycle - 1) << 16;

    /*再设置活跃周期  活跃周期要小于总周期*/
    (*pwm0_period) &= ~((unsigned int)65535 << 0); //将15～0位设置零
    (*pwm0_period) |= (unsigned int)pwm_duty << 0; //将15～0位设置为pwm_duty

    /*最后应该设置PWM_CH0_EN为enable*/
    (*pwm_base_map) &= ~((unsigned int)1 << 4); //先将第4位设置0 ---> disable
    (*pwm_base_map) |= (unsigned int)1 << 4;    //将第4位设置1 ---> enable PWM0
    //printf("PWM ENABLE DUTY:%d\n",pwm_duty);
    //sleep(5);
}

void PWM0_UnInit(void)
{
    if ((munmap(base_map, PageSize * 2)) == 0) //取消映射
    {
        printf("unmap success!\r\n");
    }
    else
    {
        printf("unmap failed!\r\n");
    }
    return 0;
}

void PWM1_Init(void)
{
    if ((mem_fd = open("/dev/mem", O_RDWR)) < 0)
    {
        printf("open error\r\n");
        return;
    }

    PageSize = sysconf(_SC_PAGESIZE); //使用sysconf查询系统页面大小
    PageMask = (~(PageSize - 1));     //页掩码
    //printf("PageSize:%d,PageMask:0x%.8X\r\n", PageSize, PageMask);

    addr_start = PIO_BASE_ADDR & PageMask;   //0x01C20800 & 0xfffff000 =  0x1C20000
    addr_offset = PIO_BASE_ADDR & ~PageMask; //0x01C20800 & 0x00000100 = 0x800
    //printf("addr_start:%.8X,addr_offset:0x%.8X\r\n", addr_start, addr_offset);

    //mmap(系统自动分配内存地址，映射区长度“内存页的整数倍”，选择可读可写，MAP_SHARED=与其他所有映射到这个对象的进程共享空间，文件句柄，被映射内容的起点)
    //offest 映射物理内存的话，必须页对其!!!   所以这个起始地址应该是0x1000的整数倍，那么明显0x01C20800需要减去0x800才是整数倍！
    if ((base_map = (unsigned int *)mmap(NULL, PageSize * 2, PROT_READ | PROT_WRITE, MAP_SHARED, mem_fd, addr_start)) == NULL)
    {
        printf("mmap error\r\n");
        close(mem_fd);
        return;
    }
    //printf("base_map:0x%.8X\n", (unsigned int)base_map);
    close(mem_fd); //映射好之后就可以关闭文件

    //--------------------------------------
    //这里已经将0x1c20000的地址映射到了内存中，但是我们需要的地址是0x01C20800，所以要再加上地址偏移量～
    gpio_map = (unsigned int)base_map + PIO_ADDR_OFF; //加上偏移量必选先把他转化成unsigend int才可以相加
    //printf("gpio_map:0x%.8X\n", (unsigned int)gpio_map);
    gpio_cfg = (unsigned int)gpio_map + PIO_CFG_OFF; //gpioB控制寄存器地址
    //printf("gpio_cfg:0x%.8X\n", (unsigned int)gpio_cfg);
    gpio_dat = (unsigned int)gpio_map + PIO_DAT_OFF; //gpioB数据寄存器地址
    //printf("gpio_dat:0x%.8X\n", (unsigned int)gpio_dat);

    /*PB5点灯*/
    (*gpio_cfg) &= ~((unsigned int)7 << 20); //先将对应位置0
    (*gpio_cfg) |= ((unsigned int)1 << 20);  //PB5 设定out
    (*gpio_dat) &= ~(1 << 5);                //开灯
    //sleep(3);
}

void PWM1_Config(unsigned int pwm_cycle, unsigned int pwm_duty)
{
    //PB5设定PWM输出
    (*gpio_cfg) &= ~((unsigned int)7 << 20);
    (*gpio_cfg) |= ((unsigned int)1 << 21); //PB5 设定PWM1模式
    //我们需要的地址是0x01C21400，所以要再加上地址偏移量
    pwm_base_map = (unsigned int)base_map + PWM_ADDR_OFF; //pwm_base_map也是pwm控制寄存器 初始值是0x00000000
    //printf("pwm_base_map:0x%.8X\n", (unsigned int)pwm_base_map);

    /*首先设置PWM1 预分頻*/                      //PWM_CH1_PRESCAL
    (*pwm_base_map) &= ~((unsigned int)15 << 15); //先将15~18位设置0
    (*pwm_base_map) |= (unsigned int)1 << 16;     //将15～18位设置为 0010 ---> 对应分頻1-->24M/240 Hz
    (*pwm_base_map) &= ~((unsigned int)1 << 20);  //先将第20位设置0
    (*pwm_base_map) |= (unsigned int)1 << 20;     //将第20位设置1 ---> 高电平有效
    /*可能要设置SCLK_CH1_GATING为mask*/
    (*pwm_base_map) &= ~((unsigned int)1 << 21); //先将第21位设置0
    (*pwm_base_map) |= (unsigned int)1 << 21;    //将第21位设置1 ---> 设置为自定义预分頻系数

    /*再设置pwm1占空比*/
    pwm1_period = (unsigned int)pwm_base_map + PWM_CH1_OFF; //pwm1_period设置pwm_ch1的占空比寄存器
    //printf("pwm1_period:0x%.8X\n", (unsigned int)pwm1_period);

    /*先设置总周期*/                                //PWM周期的计算应该是这样 OSC 24MHz / Pre-scalar / (entire cycles + 1)
    (*pwm1_period) &= ~((unsigned int)65535 << 16); //将31～16位设置零
    //24Mhz / 1 / (pwm_cycle+1)
    (*pwm1_period) |= (unsigned int)(pwm_cycle - 1) << 16;

    /*再设置活跃周期  活跃周期要小于总周期*/
    (*pwm1_period) &= ~((unsigned int)65535 << 0); //将15～0位设置零
    (*pwm1_period) |= (unsigned int)pwm_duty << 0; //将15～0位设置为pwm_duty

    /*最后应该设置PWM_CH1_EN为enable*/
    (*pwm_base_map) &= ~((unsigned int)1 << 19); //先将第19位设置0 ---> disable
    (*pwm_base_map) |= (unsigned int)1 << 19;    //将第19位设置1 ---> enable PWM1
    //printf("PWM ENABLE DUTY:%d\n",pwm_duty);
    //sleep(5);
}

void PWM1_UnInit(void)
{
    if ((munmap(base_map, PageSize * 2)) == 0) //取消映射
    {
        printf("unmap success!\r\n");
    }
    else
    {
        printf("unmap failed!\r\n");
    }
    return 0;
}
