#ifndef __BSP_UART_H__
#define __BSP_UART_H__

#include <stdio.h>
#include <stdlib.h>     /*标准函数库定义*/
#include <unistd.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <termios.h>    /*PPSIX 终端控制定义*/
#include <errno.h>      /*错误号定义*/
#include <string.h>
#include <time.h>
#include <sys/time.h>
#include <sys/wait.h>

#define pathUart1 "/dev/ttyS1" //打开串口1的设备文件
#define pathUart2 "/dev/ttyS2" //打开串口2的设备文件

#define txSize 200
#define rxSize 200

extern int fdUart1;
extern int fdUart2;

extern char uart1_tx_buf[txSize];
extern char uart1_rx_buf[rxSize];
extern char uart2_tx_buf[txSize];
extern char uart2_rx_buf[rxSize];

void bsp_uart1_Setup();
void bsp_uart2_Setup();

#endif
