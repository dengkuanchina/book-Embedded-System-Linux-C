#ifndef __BSP_I2C_H
#define __BSP_I2C_H

#include <string.h>
#include <stdio.h>
#include <stdint.h>

#define PortSDA PB
#define PinSDA 7
#define PortSCL PB
#define PinSCL 6

void I2C_Init(void);
void I2C_UnInit(void);
void I2C_Start(void);
void I2C_Stop(void);
unsigned char I2C_Wait_Ack(void);
void I2C_Write_Byte(unsigned char txd);
unsigned char I2C_Read_Byte(unsigned char ack);

#endif