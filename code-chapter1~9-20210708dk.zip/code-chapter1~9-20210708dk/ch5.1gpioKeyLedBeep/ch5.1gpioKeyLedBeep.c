#include "../includeAll.h"

#define PortLED1 PG
#define PinLED1 3
#define PortBEEP PG
#define PinBEEP 4
#define PortKEY PG
#define PinKEY 5

int main()
{
    int key = 0;    //int i, key, timer = 0;
    
    GPIO_Init();
    GPIO_ConfigPinMode(PortLED1, PinLED1, OUT);
    GPIO_ConfigPinMode(PortBEEP, PinBEEP, OUT);
    GPIO_ConfigPinMode(PortKEY, PinKEY, IN); //key设置为输入
    GPIO_SetPin(PortLED1, PinLED1, 1);
    GPIO_SetPin(PortBEEP, PinBEEP, 0);

    while (1)
    {
        key = GPIO_GetPin(PortKEY, PinKEY); //获取按键电平状态
        if (key == 1)                       //按键未按下时是高电平，LED闪烁的周期为100ms，占空比50%
        {
            GPIO_SetPin(PortLED1, PinLED1, 0);
            usleep(50 * 1000); //500*1000的乘法运算,是在程序编译时就计算出了结果,不是程序运行时才执行乘法运算,所以不占用运行时间.如果直接写500000,程序的可读性较差
            GPIO_SetPin(PortLED1, PinLED1, 1);
            usleep(50 * 1000);
        }
        else //按键按下时是低电平，无源蜂鸣器发出声音，声音的周期为1ms，占空比90%
        {
            GPIO_SetPin(PortBEEP, PinBEEP, 1);
            usleep(600);
            GPIO_SetPin(PortBEEP, PinBEEP, 0);
            usleep(400);
        }
    }

    GPIO_Free();
    return 0;
}
