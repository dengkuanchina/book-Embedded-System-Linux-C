#include "../includeAll.h"

/*******************************************************************
 * 	串口属性设置：波特率：9600；数据位：8位；停止位：1位；奇偶校验位:无；流控制：无
*******************************************************************/

int main(int argc, char **argv)
{
    int temperature, humidity, temp;

    fdUart2 = open(pathUart2, O_RDWR | O_NOCTTY | O_NDELAY);
    bsp_uart2_Setup();

    //driver_TemAndHum_init(fdUart2);

    //-------------------------
    while (1)
    {
        temp = driver_read_temperature(&temperature, &humidity);
        if (temp == 1)
        {
            printf("read temperature and humidity error!\n");
        }
        else
        {
            printf("read temperature and humidity is: %2.1f,%2.1f\n", (float)temperature / 10.0, (float)humidity / 10.0);
        }
        sleep(5);
    }
    
    close(fdUart2);
    return 0;
}
