

#ifndef __INCLUDEAll_H
#define __INCLUDEAll_H	

#include <stdint.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>     /*标准函数库定义*/
#include <unistd.h>

#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>

#include <fcntl.h>
#include <termios.h>    /*PPSIX 终端控制定义*/
#include <errno.h>      /*错误号定义*/
#include <string.h>
#include <time.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/wait.h>


#include "./bsp/bsp_gpio.h"
#include "./bsp/bsp_i2c.h"
#include "./bsp/bsp_pwm.h"
#include "./bsp/bsp_uart.h"
#include "./bsp/bsp_spi.h"

#include "./driver/driver_gpio_dht11.h"

#include "./driver/driver_uart485TemAndHum.h"
#include "./driver/driver_uart8266wifi.h"
#include "./driver/driver_uartBluetoothJDY33.h"
//#include "./driver/driver_uartLora.h"
#include "./driver/driver_uartLoraNodeToNode.h"

#include "./driver/driver_i2c_at24c02.h"
#include "./driver/driver_i2c_hmc5883l.h"
#include "./driver/driver_i2c_mpu6050.h"
#include "./driver/driver_i2c_oled.h"
#include "./driver/driver_i2c_oledfont.h"
#include "./driver/driver_i2c_pcf8591.h"
#include "./driver/driver_i2c_qmc5883l.h"
#include "./driver/driver_i2c_lm75a.h"

#include "./driver/driver_spi_adxl345.h"


#endif  
	 



