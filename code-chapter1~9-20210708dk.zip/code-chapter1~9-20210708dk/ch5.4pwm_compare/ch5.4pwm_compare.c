#include "../includeAll.h"
#define PortLED1 PG
#define PinLED1 3
#define PortKEY PG
#define PinKEY 5
//用法: time ./pwm_compare 100 50
//PWM1时钟为100khz，所以100设置的频率是1khz，对应的周期是1ms，50代表100个脉冲中50个是高电平，所以此时占空比是50%
//功能：通过按键切换软件和硬件PWM
int main(int argc, char *argv[])
{
    int i, key, timer = 0;
    int cycle, duty;
    cycle = atoi(argv[1]);
    duty = atoi(argv[2]);
    printf("argv[1] is cycle =%d;--argv[2] is duty =%d\n", cycle, duty);

    //----------------------------
    GPIO_Init();
    GPIO_ConfigPinMode(PortLED1, PinLED1, OUT);
    GPIO_ConfigPinMode(PortKEY, PinKEY, IN); //key设置为输入
    GPIO_SetPin(PortLED1, PinLED1, 1);
    PWM1_Init();

    while (1)
    {
        key = GPIO_GetPin(PortKEY, PinKEY); //获取按键电平状态
        if (key == 1)                       //按键未按下时是高电平，LED闪烁的周期为100ms，占空比50%
        {
            GPIO_SetPin(PortLED1, PinLED1, 0);
            usleep(50 * 1000); //500*1000的乘法运算,是在程序编译时就计算出了结果,不是程序运行时才执行乘法运算,所以不占用运行时间.如果直接写500000,程序的可读性较差
            GPIO_SetPin(PortLED1, PinLED1, 1);
            usleep(50 * 1000);
        }
        else //按键按下时是低电平，无源蜂鸣器发出声音，声音的周期为1ms，占空比90%
        {
            PWM1_Config(cycle, duty);
            while (0 == GPIO_GetPin(PortKEY, PinKEY)); //等待按键松开
        }
    }
    
    GPIO_Free();
    PWM1_UnInit();
    return 0;
}
